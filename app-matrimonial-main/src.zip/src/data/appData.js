import {IMAGES} from '../assets/images';
import {LABELS} from '../labels';

export const genderList = [
  {key: '1', value: 'Male'},
  {key: '2', value: 'Female'},
];
export const QualificationList = [
  {key: '1', value: 'Matric'},
  {key: '2', value: 'Intermediate'},
  {key: '3', value: 'Graduation'},
];
export const occupationList = [
  {key: '1', value: 'Software Engineer'},
  {key: '2', value: 'Accountant'},
  {key: '3', value: 'Doctor'},
];

export const annualIncomeList = [
  {key: '1', value: '10 Lac'},
  {key: '2', value: '12 Lac'},
  {key: '3', value: '13 Lac'},
];
export const workLocationList = [
  {key: '1', value: 'Mumbai'},
  {key: '2', value: 'Karachi'},
  {key: '3', value: 'Delhi'},
];
export const matchingPrefernce = [
  {
    key: '1',
    value: LABELS.age,
  },
  {
    key: '2',
    value: LABELS.maritalStatus,
  },
];

export const partnerPref = [
  {
    key: '1',
    value: LABELS.age,
  },
  {
    key: '2',
    value: LABELS.maritalStatus,
  },
];
export const preferedPartDetails = [
  {
    key: '1',
    value: LABELS.age,
  },
  {
    key: '2',
    value: LABELS.maritalStatus,
  },
];

export const preferDetails = [
  {
    key: '1',
    value: LABELS.age,
    rightIcon: IMAGES.height,
    leftIcon: IMAGES.vectorIcon,
  },
  {
    key: '2',
    value: LABELS.education,
    rightIcon: IMAGES.education,
    leftIcon: IMAGES.vectorIcon,
  },

  {
    key: '3',
    value: LABELS.occupation,
    rightIcon: IMAGES.occupation,
    leftIcon: IMAGES.vectorIcon,
  },
  {
    key: '4',
    value: LABELS.motherToungue,
    rightIcon: IMAGES.language,
    leftIcon: IMAGES.vectorIcon,
  },

  {
    key: '5',
    value: LABELS.AnnualIncome,
    rightIcon: IMAGES.sales,
    leftIcon: IMAGES.vectorIcon,
  },
  {
    key: '6',
    value: LABELS.sect,
    rightIcon: IMAGES.location,
    leftIcon: IMAGES.vectorIcon,
  },
  {
    key: '7',
    value: LABELS.city,
    rightIcon: IMAGES.location,
    leftIcon: IMAGES.vectorIcon,
  },
];
export const filterOptions = [
  {
    key: '1',
    value: LABELS.NewJoin,
  },
  {
    key: '2',
    value: LABELS.matches,
  },
  {
    key: '3',
    value: LABELS.nearestMe,
  },
  {
    key: '4',
    value: LABELS.Password,
  },
];
export const carouselData = [
  {
    id: '0',
    name: 'Alizabeth',
    age: '25',
    height: '160cm-5ft',
    occupation: 'Senior Sales Manager',
    location: 'India',
    isVerified: true,
    userStatus: 'New',
  },
  {
    id: '1',
    name: 'Sarah Alizeh',
    age: '23',
    height: '160cm-5ft',
    occupation: 'Senior Sales Manager',
    location: 'Sri lanka',
    isVerified: true,
    userStatus: 'New',
  },
  {
    id: '2',
    name: 'Gabreille Fiane',
    age: '24',
    height: '160cm-5ft',
    occupation: 'Software Engineer',
    location: 'America',
    isVerified: true,
    userStatus: 'New',
  },
  {
    id: '3',
    name: 'Theodera',
    age: '30',
    height: '160cm-5ft',
    occupation: 'Doctor',
    location: 'Pakistan',
    isVerified: true,
    userStatus: 'New',
  },
];

export const HorizontalCardData = [
  {
    key: 1,
    name: 'Alizabeth',
    age: '24',
    height: '160cm-5ft',
    profile: IMAGES.carousel1,
  },
  {
    key: 2,
    name: 'Alizabeth',
    age: '24',
    height: '160cm-5ft',
    profile: IMAGES.carousel1,
  },
  {
    key: 3,
    name: 'Alizabeth',
    age: '24',
    height: '160cm-5ft',
    profile: IMAGES.carousel1,
  },
];

export const verticalCardData = [
  {
    key: 1,
    name: 'Elizabeth',
    age: '24',
    height: '160cm-5ft',
    location: 'Mumbai, India',
    language: 'Hindi,Bengali',
    castName: 'Cast Name',
    profession: 'Manager',
    isVerified: true,
    profile: IMAGES.carousel1,
  },
  {
    key: 2,
    name: 'Theodera',
    age: '24',
    height: '160cm-5ft',
    location: 'Mumbai, India',
    language: 'Hindi,Bengali',
    castName: 'Cast Name',
    profession: 'Manager',
    isVerified: true,
    profile: IMAGES.carousel1,
  },
  {
    key: 3,
    name: 'Sehrish Khan',
    age: '24',
    height: '160cm-5ft',
    location: 'Mumbai, India',
    language: 'Hindi,Bengali',
    castName: 'Cast Name',
    profession: 'Manager',
    isVerified: true,
    profile: IMAGES.carousel1,
  },
  {
    key: 4,
    name: 'Allise',
    age: '24',
    height: '160cm-5ft',
    location: 'Mumbai, India',
    language: 'Hindi,Bengali',
    castName: 'Cast Name',
    profession: 'Manager',
    isVerified: true,
    profile: IMAGES.carousel1,
  },
];

export const DrawerListData = [
  {
    key: '1',
    name: 'User Name',
    description: 'Clark-Michel@email',
    iconName: IMAGES.userIcon,
    onScreenPress: () => {},
    isActive: true,
    onClick: () => {
      updateState(prevState => ({
        ...prevState,
        isActive: !prevState.isActive,
      }));
    },
  },
  {
    key: '2',
    name: 'Active Status',
    description: 'Turn on & off your matrimoney proposal you have received',
    iconName: IMAGES.statusIcon,
    onScreenPress: () => {},
    isActive: false,
  },
  {
    key: '3',
    name: 'Connections',
    description: 'See all of your marriage proposal you have recived',
    iconName: IMAGES.connectionsIcon,
    onScreenPress: () => {},
    isActive: false,
  },
  {
    key: '4',
    name: 'Membership',
    description:
      'Choose your membership plan for you it will give you more access & options.',
    iconName: IMAGES.membershipIcon,
    onScreenPress: () => {},
    isActive: false,
  },
  {
    key: '5',
    name: 'Payment Method',
    description:
      'Choose your membership plan for you it will give you more access & options.',
    iconName: IMAGES.paymentIcon,
    onScreenPress: () => {},
    isActive: false,
  },
  {
    key: '6',
    name: 'Account Setting',
    description: 'Manage Your account information, email password sign out etc',
    iconName: IMAGES.settingIcon,
    onScreenPress: () => {},
    isActive: false,
  },
  {
    key: '7',
    name: 'Privacy & Policy',
    description: 'Manage Your account information, email password sign out etc',
    iconName: IMAGES.privacyIcon,
    onScreenPress: () => {},
    isActive: false,
  },
  {
    key: '8',
    name: 'Log Out',
    description: 'Clark-Michel@email',
    iconName: IMAGES.logoutIcon,
    onScreenPress: () => {},
    isActive: false,
  },
];
export const professionPreferenceData = [
  {
    key: '1',
    category: 'Engineer',
    data: [
      {
        key: '01',
        value: 'Professor',
        isChecked: false,
      },
      {
        key: '02',
        value: 'Marketing Manager',
        isChecked: false,
      },
      {
        key: '03',
        value: 'Software Engineer',
        isChecked: false,
      },
      {
        key: '04',
        value: 'Civil Engineer',
        isChecked: false,
      },
      {
        key: '05',
        value: 'Project Manager',
        isChecked: false,
      },
      {
        key: '06',
        value: 'Business Man',
        isChecked: false,
      },
      {
        key: '07',
        value: 'Project Manager',
        isChecked: false,
      },
      {
        key: '08',
        value: 'Project Manager',
        isChecked: false,
      },
    ],
  },

  {
    key: '2',
    category: 'Doctor',
    data: [
      {
        key: '01',
        value: 'Allopathy',
        isChecked: false,
      },
      {
        key: '02',
        value: 'Homeopathy',
      },
      {
        key: '03',
        value: 'Cardiologist',
      },
      {
        key: '04',
        value: 'Normal Doctor',
      },
      {
        key: '05',
        value: 'Project Manager',
      },
      {
        key: '06',
        value: 'Business Man',
      },
      {
        key: '07',
        value: 'Project Manager',
      },
      {
        key: '08',
        value: 'Project Manager',
      },
    ],
  },

  {
    key: '3',
    category: 'Tech Lead',
    data: [
      {
        key: '01',
        value: 'Digital Marketer',
      },
      {
        key: '02',
        value: 'Graphic Designer',
      },
      {
        key: '03',
        value: 'Content Writer',
      },
      {
        key: '04',
        value: 'Project Manager',
      },
      {
        key: '05',
        value: 'Hiring Associate',
      },
      {
        key: '06',
        value: 'Communicator',
      },
      {
        key: '07',
        value: 'SEO Marketer',
      },
      {
        key: '08',
        value: 'Data Analytics',
      },
    ],
  },
  {
    key: '4',
    category: 'Others',
    data: [
      {
        key: '01',
        value: 'Teacher',
      },
      {
        key: '02',
        value: 'Manager',
      },
      {
        key: '03',
        value: 'Incharge',
      },
      {
        key: '04',
        value: 'Machenic',
      },
      {
        key: '05',
        value: 'Beautician',
      },
      {
        key: '06',
        value: 'Business Man',
      },
      {
        key: '07',
        value: 'Project Manager',
      },
      {
        key: '08',
        value: 'Hr',
      },
    ],
  },
];
const searchDummyData = [
  {key: '1', value: 'Alizabeth'},
  {
    key: '2',
    value: 'Theodera',
  },
  {
    key: '3',
    value: 'Sehrish Khan',
  },
  {
    key: '4',
    value: 'Mehwish Khan',
  },
  {
    key: '5',
    value: 'Anum Khan',
  },
];
export const inboxData = [
  {
    senderName: 'Niloy Chakraborty',
    senderId: '#0321',
    message: 'Not too bad, thanks! Just got off work. How about you?',
    messageCount: '2',
    isMessageArrived: true,
    messageTime: '11:30',
    senderProfile: IMAGES.carousel1,
  },
  {
    senderName: 'Niloy Chakraborty',
    senderId: '#0421',
    message: 'Hard to choose, but I am a big fan of Italian. How about you?',
    isMessageArrived: false,
    messageCount: '0',
    messageTime: '12:50',
    senderProfile: IMAGES.carousel1,
  },
  {
    senderName: 'Niloy Chakraborty',
    senderId: '#0521',
    message: 'Italian is great! I love sushi,too',
    isMessageArrived: false,
    messageCount: '0',
    messageTime: '11:30',
    senderProfile: IMAGES.carousel1,
  },
  {
    senderName: 'Niloy Chakraborty',
    senderId: '#0621',
    message: 'I am a fan of spicy tuna rolls. How about you?',
    isMessageArrived: true,
    messageCount: '0',
    messageTime: '12:50',
    senderProfile: IMAGES.carousel1,
  },
  {
    senderName: 'Niloy Chakraborty',
    senderId: '#0721',
    message: 'Spicy tuna rolls are a classic! I like rainbow rolls.',
    isMessageArrived: true,
    messageCount: '0',
    messageTime: '11:30',
    senderProfile: IMAGES.carousel1,
  },
  {
    senderName: 'Niloy Chakraborty',
    senderId: '#0821',
    message: 'Not too bad, thanks! Just got off work. How about you?',
    isMessageArrived: true,
    messageCount: '4',
    messageTime: '11:30',
    senderProfile: IMAGES.carousel1,
  },
  {
    senderName: 'Niloy Chakraborty',
    senderId: '#0921',
    message: 'Not too bad, thanks! Just got off work. How about you?',
    isMessageArrived: true,
    messageCount: '1',
    messageTime: '11:30',
    senderProfile: IMAGES.carousel1,
  },
];
export const notificationsData = [
  {
    id: '1',
    message: 'You have a new message from John Doe.',
    timestamp: new Date('2023-05-15T09:30:00Z'),
    profileImage: IMAGES.carousel1,
  },
  {
    id: '2',
    message: 'Your friend Sarah sent you a friend request.',
    timestamp: new Date('2023-05-14T15:45:00Z'),
    profileImage: IMAGES.carousel1,
  },
  {
    id: '3',
    message: 'You have a meeting scheduled at 2:00 PM.',
    timestamp: new Date('2023-10-14T11:20:00Z'),
    profileImage: IMAGES.carousel1,
  },
  {
    id: '4',
    message: 'New items added to your wishlist.',
    timestamp: new Date('2023-10-13T20:10:00Z'),
    profileImage: IMAGES.carousel1,
  },
  {
    id: '5',
    message: 'you have a meeting schedule at 2: 00 PM',
    timestamp: new Date('2023-10-13T20:10:00Z'),
    profileImage: IMAGES.carousel1,
  },
  {
    id: '6',
    message: 'New items added to your wishlist.',
    timestamp: new Date('2023-10-13T20:10:00Z'),
    profileImage: IMAGES.carousel1,
  },
  {
    id: '7',
    message: 'New items added to your wishlist.',
    timestamp: new Date('2023-10-13T20:10:00Z'),
    profileImage: IMAGES.carousel1,
  },
  {
    id: '8',
    message: 'New items added to your wishlist.',
    timestamp: new Date('2023-10-13T20:10:00Z'),
    profileImage: IMAGES.carousel1,
  },
  {
    id: '9',
    message: 'New items added to your wishlist.',
    timestamp: new Date('2023-10-13T20:10:00Z'),
    profileImage: IMAGES.carousel1,
  },
];
export const profilePictures = [
  {
    key: '1',
    img: IMAGES.profile1,
  },
  {
    key: '2',
    img: IMAGES.profile2,
  },
  {
    key: '3',
    img: IMAGES.profile1,
  },
  {
    key: '4',
    img: IMAGES.profile2,
  },
];

export const profileUpdateData = [
  {
    key: 1,
    value: 'Account',
    isSelected: false,
  },

  {
    key: 2,
    value: 'Personal',
    isSelected: false,
  },
  {
    key: 3,
    value: 'Professional',
    isSelected: false,
  },
];
export const connectionStatus = [
  {
    key: 1,
    value: 'Accepted',
    isSelected: false,
  },

  {
    key: 2,
    value: 'Request',
    isSelected: false,
  },
  {
    key: 3,
    value: 'Pending',
    isSelected: false,
  },
];

export const connectionChat = [
  {
    key: '1',
    message: 'Hard to choose, but I am a big fan of..',
    profession: 'Software Engineer',
    senderName: 'Alena Baptista',
    timestamp: new Date('2023-10-13T20:10:00Z'),
    senderProfile: IMAGES.carousel1,
  },
  {
    key: '2',
    message: 'Hard to choose, but I am a big fan of..',
    profession: 'Software Engineer',
    senderName: 'Alena Baptista',
    timestamp: new Date('2023-10-13T20:10:00Z'),
    senderProfile: IMAGES.carousel1,
  },
  {
    key: '3',
    message: 'Hard to choose, but I am a big fan of..',
    profession: 'Software Engineer',
    senderName: 'Alena Baptista',
    timestamp: new Date('2023-10-13T20:10:00Z'),
    senderProfile: IMAGES.carousel1,
  },
  {
    key: '4',
    message: 'Hard to choose, but I am a big fan of..',
    profession: 'Software Engineer',
    senderName: 'Alena Baptista',
    timestamp: new Date('2023-10-13T20:10:00Z'),
    senderProfile: IMAGES.carousel1,
  },
  {
    key: '5',
    message: 'Hard to choose, but I am a big fan of..',
    profession: 'Software Engineer',
    senderName: 'Alena Baptista',
    timestamp: new Date('2023-10-13T20:10:00Z'),
    senderProfile: IMAGES.carousel1,
  },
  {
    key: '6',
    message: 'Hard to choose, but I am a big fan of..',
    profession: 'Software Engineer',
    senderName: 'Alena Baptista',
    timestamp: new Date('2023-10-13T20:10:00Z'),
    senderProfile: IMAGES.carousel1,
  },
  {
    key: '7',
    message: 'Hard to choose, but I am a big fan of..',
    profession: 'Software Engineer',
    senderName: 'Alena Baptista',
    timestamp: new Date('2023-10-13T20:10:00Z'),
    senderProfile: IMAGES.carousel1,
  },
];
