import React from 'react';
import {View, Text} from 'react-native';
import {styles} from './styles';
import CustomImage from '../CustomImage/CustomImage';
import FastImage from 'react-native-fast-image';
import {IMAGES} from '../../assets/images';
const LayoutImage = ({imgSrc = IMAGES.layout1}) => {
  const style = styles();
  return (
    <View style={[style.imgContainer]}>
      <FastImage source={imgSrc} style={{flex: 1}} resizeMode='cover'/>
    </View>
  );
};

export default LayoutImage;
