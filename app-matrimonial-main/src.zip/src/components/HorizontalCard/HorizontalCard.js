import {View, Text, ScrollView, TouchableOpacity, Image} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {COLORS, STYLES} from '../../assets/theme';
import AppText from '../AppText/AppText';
import {Fonts} from '../../assets/fonts';
import {LABELS} from '../../labels';
import Icon from '../Icon/Icon';
import {SVG} from '../../assets/svg';
import Space from '../Space/Space';
import CustomImage from '../CustomImage/CustomImage';
import {IMAGES} from '../../assets/images';
import FastImage from 'react-native-fast-image';

const HorizontalCard = ({data, onLinkPress}) => {
  const style = styles();
  return (
    <>
      <View style={style.parentContainer()}>
        <View style={style.textContainer()}>
          <AppText
            title={LABELS.recentlyViewed}
            variant={'h3'}
            extraStyle={[STYLES.fontFamily(Fonts.PoppinsSemiBold)]}
          />
          <TouchableOpacity style={style.linkContainer()} onPress={onLinkPress}>
            <AppText
              title={LABELS.seeMore}
              variant={'h5'}
              extraStyle={[STYLES.fontFamily(Fonts.PoppinsRegular)]}
              color={COLORS.dark.primary}
            />
            <View>
              <Icon
                SVGIcon={
                  <SVG.vectorIcon
                    fill={COLORS.dark.primary}
                    iconLeft={true}
                    height={'10'}
                    width={'10'}
                  />
                }
              />
            </View>
          </TouchableOpacity>
        </View>

        <ScrollView
          horizontal={true}
          showsHorizontalScrollIndicator={false}
          style={style.horizontalScrollContainer()}>
          {data ? (
            data.map((item, index) => {
              console.log(item.key);
              return (
                <>
                  <View style={style.cardContainer()} key={item.key + index}>
                    <View style={style.imgContainer()}>
                      <FastImage
                        source={item.profile}
                        resizeMode="cover"
                        style={style.img()}
                      />
                    </View>

                    <View style={style.contentContainer()}>
                      <AppText
                        title={item.name}
                        variant={'h4'}
                        color={COLORS.dark.black}
                        extraStyle={{fontFamily: Fonts.PoppinsMedium}}
                      />
                      <AppText
                        title={`Age${item.age} , ${item.height}`}
                        color={COLORS.dark.inputBorder}
                        extraStyle={{
                          fontFamily: Fonts.PoppinsRegular,
                          bottom: '5%',
                        }}
                      />

                      <View
                        style={{
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                        }}>
                        <TouchableOpacity style={style.sendIconBtn()}>
                          <CustomImage
                            source={IMAGES.sendIcon}
                            size={11}
                            resizeMode={'contain'}
                          />
                        </TouchableOpacity>

                        <TouchableOpacity style={style.chatIconBtn()}>
                          <CustomImage
                            source={IMAGES.chatIcon}
                            size={11}
                            resizeMode={'contain'}
                          />
                        </TouchableOpacity>
                        <TouchableOpacity style={style.verifyIconBtn()}>
                          <CustomImage
                            source={IMAGES.verifyIcon}
                            size={11}
                            resizeMode={'contain'}
                          />
                        </TouchableOpacity>
                      </View>
                    </View>
                  </View>
                  <Space mL={10} />
                </>
              );
            })
          ) : (
            <></>
          )}
        </ScrollView>
      </View>
    </>
  );
};

export default HorizontalCard;
