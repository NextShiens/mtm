import React from 'react';
import {Text, StyleSheet, View} from 'react-native';
import FastImage from 'react-native-fast-image';
import {ResizeMode, styles} from './styles';
import {IMAGES} from '../../assets/images';
import {STYLES} from '../../assets/theme';

const CustomImage = props => {
  const {
    source,
    uri,
    size = 150,
    alignSelf = 'center',
    resizeMode = 'cover',
    extraStyle = {container: {}},
    onPress,
  } = props;
  const style = styles();
  return (
    <View onPress={onPress}>
      <FastImage
        source={uri ? {uri} : source}
        style={[
          style.container(size),
          extraStyle.container,
          STYLES.alignSelf(alignSelf),
        ]}
        resizeMode={resizeMode}
      />
    </View>
  );
};

export default CustomImage;
