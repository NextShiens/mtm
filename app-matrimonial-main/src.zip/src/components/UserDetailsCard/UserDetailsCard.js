import React from 'react';
import {View, TouchableOpacity} from 'react-native';
import {Text} from 'react-native';
import {styles} from './styles';
import AppText from '../AppText/AppText';
import CustomImage from '../CustomImage/CustomImage';
import {IMAGES} from '../../assets/images';
import {HORIZON_MARGIN} from '../../assets/theme';
import {LABELS} from '../../labels';
import Space from '../Space/Space';

const UserDetailsCard = ({
  extraStyle,
  leftIcon,
  rightIcon,
  data,
  onRightIconPress,
  onLeftIconPress,
}) => {
  const style = styles();
  return (
    <>
      {data ? (
        data.map(item => {
          return (
            <>
              <View style={style.contentContainer()} key={item.key}>
                <TouchableOpacity
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    width: '100%',
                  }}
                  key={item.key}>
                  <View
                    style={{
                      width: '95%',
                      flexDirection: 'row',
                      alignItems: 'center',
                    }}>
                    <CustomImage
                      source={item.rightIcon}
                      size={12}
                      resizeMode={'contain'}
                    />
                    <View style={{width: 10}}></View>
                    <AppText
                      title={item.value}
                      extraStyle={style.text()}
                      variant={'h5'}
                    />
                  </View>
                  <CustomImage
                    source={IMAGES.arrowIcon}
                    size={12}
                    resizeMode={'contain'}
                  />
                </TouchableOpacity>
              </View>
              <View style={style.hr()}></View>
            </>
          );
        })
      ) : (
        <></>
      )}
    </>
  );
};

export default UserDetailsCard;
