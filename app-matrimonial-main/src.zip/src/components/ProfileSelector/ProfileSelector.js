import {View, ScrollView} from 'react-native';
import React, {useState} from 'react';
import {styles} from './styles';
import CustomImage from '../CustomImage/CustomImage';
import {IMAGES} from '../../assets/images';
import Space from '../Space/Space';
import AppButton from '../AppButton/AppButton';
import {COLORS, HORIZON_MARGIN} from '../../assets/theme';

const ProfileSelector = ({isCameraShown, profiles, profileData}) => {
  const style = styles();
  const [isSelected, setIsSelected] = useState(false);
  const [selectedBtn, setSelectedBtn] = useState('1');
  const handleProfileUpdate = item => {
    setSelectedBtn(item.key);
    setIsSelected(!isSelected);
    console.log('selected item', item);
  };
  return (
    <>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <View
          style={[
            isCameraShown
              ? style.profileContainer()
              : style.withoutCameraContainer(),
          ]}>
          {isCameraShown ? (
            <View style={style.uploadImgContainer()}>
              <CustomImage
                source={IMAGES.camera}
                size={20}
                resizeMode={'contain'}
              />
            </View>
          ) : (
            <></>
          )}

          {profiles ? (
            profiles.map(item => {
              return (
                <CustomImage
                  source={item.img}
                  size={100}
                  resizeMode={'contain'}
                  key={item.key}
                />
              );
            })
          ) : (
            <></>
          )}
        </View>
      </ScrollView>
      <Space mT={20} />
      <View style={{width: '100%', paddingHorizontal: HORIZON_MARGIN}}>
        <View
          style={{
            height: 55,
            width: '100%',
            backgroundColor: COLORS.dark.lightblue,
            justifyContent: 'center',
            flexDirection: 'row',
          }}>
          {profileData.map(item => {
            return (
              <AppButton
                variant="filled"
                key={item.key}
                extraStyle={{
                  container: [
                    selectedBtn === item.key
                      ? style.selectedBtn()
                      : style.unSelectedBtn(),
                  ],
                  text: [
                    selectedBtn === item.key
                      ? style.selectedText()
                      : style.unSelectedText(),
                  ],
                }}
                title={item.value}
                onPress={() => {
                  handleProfileUpdate(item);
                }}
              />
            );
          })}
        </View>
      </View>
    </>
  );
};

export default ProfileSelector;
