import {View, Text, TouchableOpacity} from 'react-native';
import React from 'react';
import CustomImage from '../CustomImage/CustomImage';
import Space from '../Space/Space';
import AppText from '../AppText/AppText';
import {COLORS} from '../../assets/theme';
import {IMAGES} from '../../assets/images';
import {LABELS} from '../../labels';
import {styles} from './styles';
import {windowWidth} from '../InboxCard/style';
import {Fonts} from '../../assets/fonts';

const ConnectionsInboxCard = ({data, selectedChat}) => {
  const style = styles();
  console.log(data);
  return (
    <>
      {data.map(item => {
        return (
          <TouchableOpacity key={item.key}>
            <View
              //   style={
              //     item.messageCount > 0
              //       ? style.unreadCardContainer()
              //       : style.readCardContainer()
              //   }
              style={style.readCardContainer()}>
              <View style={style.profileContainer()}>
                <CustomImage
                  source={item.senderProfile}
                  size={windowWidth * 0.15}
                  extraStyle={{container: {borderRadius: 25}}}
                />
              </View>
              <Space mL={5} />

              {/* <View style={style.textContainer()}>
                <AppText
                  title={item.senderName}
                  variant={'h5'}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                />
                <AppText
                  title={item.profession}
                  variant={'h5'}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                />

                <AppText
                  title={item.message}
                  numberOfLines={1}
                  variant={'h5'}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                  color={
                    // item.messageCount > 0
                    //   ? COLORS.dark.black
                    //   :
                    COLORS.dark.inputBorder
                  }
                  elipsizeMode="tail"
                />
              </View> */}
              <View style={style.newTextContainer()}>
                <View
                  style={{
                    width: '100%',
                    justifyContent: 'space-between',
                    flexDirection: 'row',
                  }}>
                  <AppText title={'Halle there'} />
                  <AppText title={'11:30'} />
                </View>
              </View>

              {/* <View style={style.timeContainer()}>
                <AppText
                  title={item.messageTime}
                  color={COLORS.dark.inputBorder}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                />
                <Space mT={5} /> */}
              {/* <View
                  style={
                    item.messageCount > 0
                      ? style.messageCountContainer()
                      : style.nullContainer()
                  }>
                  <AppText
                    title={item.messageCount > 0 ? item.messageCount : ''}
                    color={COLORS.dark.white}
                    extraStyle={{fontFamily: Fonts.PoppinsMedium}}
                  />
                </View> */}
            </View>
            {/* </View> */}
          </TouchableOpacity>
        );
      })}

      <View style={style.readCardContainer()}>
        <View style={style.profileContainer()}>
          <CustomImage
            source={IMAGES.carousel1}
            size={windowWidth * 0.15}
            extraStyle={{container: {borderRadius: 25}}}
          />
        </View>
        <Space mL={5} />
        <View style={style.textContainer()}>
          <AppText
            title={LABELS.exampleName}
            variant={'h5'}
            extraStyle={{fontFamily: Fonts.PoppinsRegular}}
          />
          <AppText
            title={LABELS.examplePara}
            numberOfLines={2}
            variant={'h6'}
            extraStyle={{fontFamily: Fonts.PoppinsRegular}}
            elipsizeMode="tail"
          />
        </View>

        <View style={style.timeContainer()}>
          <AppText
            title={'11:30'}
            color={COLORS.dark.inputBorder}
            extraStyle={{fontFamily: Fonts.PoppinsRegular}}
          />
          <Space mT={5} />
          <View style={style.nullContainer()}></View>
        </View>
      </View>
    </>
  );
};

export default ConnectionsInboxCard;
