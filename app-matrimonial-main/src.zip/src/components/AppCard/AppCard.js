import { View, Text } from 'react-native'
import React from 'react'
import { styles } from './styles';

const AppCard = () => {
    const style = styles();
  return (
    <View>
      <Text>AppCard</Text>
    </View>
  )
}

export default AppCard