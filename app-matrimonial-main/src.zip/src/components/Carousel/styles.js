import {StyleSheet} from 'react-native';
export const styles = () =>
  StyleSheet.create({
    carouselContainer: () => ({
      width: '100%',
      backgroundColor: 'pink',
      height: 280,
    }),
  });
