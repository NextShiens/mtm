import React, {useState} from 'react';
import {View, Image, StyleSheet, Dimensions} from 'react-native';
import Carousel, {Pagination} from 'react-native-snap-carousel';
import LinearGradient from 'react-native-linear-gradient';
import {IMAGES} from '../../assets/images';
import {COLORS, HORIZON_MARGIN} from '../../assets/theme';
import FastImage from 'react-native-fast-image';
const {width} = Dimensions.get('window');

const CarouselCard = () => {
  const [activeSlide, setActiveSlide] = useState(0);
  const data = [
    {image: IMAGES.carousel1, key: '1'},
    {image: IMAGES.carousel1, key: '2'},
    {image: IMAGES.carousel1, key: '3'},
    {image: IMAGES.carousel1, key: '4'},
  ];
  const renderItem = ({item}) => {
    return (
      <View style={styles.slide}>
        <FastImage
          source={item.image}
          style={styles.image}
          resizeMode={'cover'}
        />
        <LinearGradient
          colors={['transparent', COLORS.dark.secondary]}
          style={styles.gradient}
        />
      </View>
    );
  };

  return (
    <>
      <Carousel
        data={data}
        renderItem={renderItem}
        sliderWidth={width * 0.9}
        itemWidth={width}
        onSnapToItem={index => setActiveSlide(index)}
      />
      <Pagination
        dotsLength={data.length}
        activeDotIndex={activeSlide}
        containerStyle={styles.paginationContainer}
        dotStyle={styles.paginationDot}
        inactiveDotOpacity={0.4}
        inactiveDotScale={0.6}
      />
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  slide: {
    width,
    height: 250,
  },
  image: {
    ...StyleSheet.absoluteFillObject,
    resizeMode: 'cover',
    borderRadius: 10,
  },
  gradient: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 10,
  },
  paginationContainer: {
    position: 'absolute',
    bottom: 1,
    alignSelf: 'center',
  },
  paginationDot: {
    width: 12,
    height: 4,
    borderRadius: 4,
    marginHorizontal: 8,
    backgroundColor: COLORS.dark.primary,
  },
  flexContainer: {
    width: '100%',
    paddingHorizontal: HORIZON_MARGIN,
  },
  userStatusBtn: {
    height: 25,
    width: '25%',

    backgroundColor: COLORS.dark.primary,
  },
});

export default CarouselCard;
