import {configureStore} from '@reduxjs/toolkit';
import themeReducer from './slices/appSlice';
export const store = configureStore({
  reducer: {
    theme: themeReducer,
  },
});
