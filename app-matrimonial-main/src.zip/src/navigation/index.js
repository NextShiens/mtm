import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import InitialScreen from '../screens/Auth/InitialScreen/InitialScreen';
import RegisterScreen from '../screens/Auth/RegisterScreen/RegisterScreen';
import LoginScreen from '../screens/Auth/LoginScreen/LoginScreen';
import OTPScreen from '../screens/Auth/OTPScreen/OTPScreen';
import ProfileCreateScreen from '../screens/Auth/ProfileCreation/ProfileCreateScreen';
import ProfileDetailsScreen from '../screens/Auth/ProfileDetailsScreen/ProfileDetailsScreen';
import PartnerReferenceScreen from '../screens/Auth/PartnerReferenceScreen/PartnerReferenceScreen';
import HomePage from '../screens/Main/HomePage/HomePage';
import PartnerMatch from '../screens/Main/ParterMatch/PartnerMatch';
import AccountsSetting from '../screens/Main/AccountsSetting/AccountsSetting';
import InboxScreen from '../screens/Main/InboxScreen/InboxScreen';
import MembershipPlan from '../screens/Main/MembershipPlan/MembershipPlan';
import NotificationScreen from '../screens/Main/NotificationScreen/NotificationScreen';
import PaymentScreen from '../screens/Main/PaymentScreen/PaymentScreen';
import SettingScreen from '../screens/Main/SettingScreen/SettingScreen';
import UserPrivacyScreen from '../screens/Main/UserPrivacyScreen/UserPrivacyScreen';
import BottomNavigation from './BottomNavigation/BottomNavigation';
import DrawerNavigation from './DrawerNavigation/DrawerNavigation';
import UserDetailsScreen from '../screens/Main/UserDetailsScreen/UserDetailsScreen';
import {ProfileUpdateScreen} from '../screens';
import AcceptedConnections from '../screens/Main/AcceptedConnections/AcceptedConnections';
import RequestedConnections from '../screens/Main/RequestedConnections/RequestedConnections';
import PendingConnections from '../screens/Main/PendingConnections/PendingConnections';

const Stack = createNativeStackNavigator();
const options = {headerShown: false};
const AuthStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="InitialScreen"
        component={InitialScreen}
        options={options}
      />
      <Stack.Screen
        name="RegisterScreen"
        component={RegisterScreen}
        options={options}
      />
      <Stack.Screen
        name="LoginScreen"
        component={LoginScreen}
        options={options}
      />
      <Stack.Screen name="OTPScreen" component={OTPScreen} options={options} />

      <Stack.Screen
        name="ProfileCreateScreen"
        component={ProfileCreateScreen}
        options={options}
      />
      <Stack.Screen
        name="ProfileDetailsScreen"
        component={ProfileDetailsScreen}
        options={options}
      />
      <Stack.Screen
        name="PartnerReferenceScreen"
        component={PartnerReferenceScreen}
        options={options}
      />

      <Stack.Screen
        name="PartnerMatch"
        component={PartnerMatch}
        options={options}
      />
    </Stack.Navigator>
  );
};

const HomeStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="AccountSetting"
        component={AccountsSetting}
        options={options}
      />
      <Stack.Screen
        name="ProfileUpadateScreen"
        component={ProfileUpdateScreen}
        options={options}
      />
      <Stack.Screen
        name="AcceptedConnections"
        component={AcceptedConnections}
        options={options}
      />
      <Stack.Screen
        name="RequestedConnections"
        component={RequestedConnections}
        options={options}
      />
      <Stack.Screen
        name="PendingConnections"
        component={PendingConnections}
        options={options}
      />
      <Stack.Screen name="HomePage" component={HomePage} options={options} />
      <Stack.Screen
        name="InboxScreen"
        component={InboxScreen}
        options={options}
      />
      <Stack.Screen
        name="MembershipPlan"
        component={MembershipPlan}
        options={options}
      />
      <Stack.Screen
        name="NotificationScreen"
        component={NotificationScreen}
        options={options}
      />
      <Stack.Screen
        name="PartnerMatch"
        component={PartnerMatch}
        options={options}
      />
      <Stack.Screen
        name="PaymentScreen"
        component={PaymentScreen}
        options={options}
      />
      <Stack.Screen
        name="SettingScreen"
        component={SettingScreen}
        options={options}
      />
      <Stack.Screen
        name="UserPrivacy"
        component={UserPrivacyScreen}
        options={options}
      />
      <Stack.Screen
        name="UserDetailsScreen"
        component={UserDetailsScreen}
        options={options}
      />
    </Stack.Navigator>
  );
};

const RootNavigator = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen name="AuthStack" component={AuthStack} options={options} />
      <Stack.Screen name="HomeStack" component={HomeStack} options={options} />
      <Stack.Screen
        name="Home"
        component={BottomNavigation}
        options={options}
      />
      <Stack.Screen
        name="DrawerNavigation"
        component={DrawerNavigation}
        options={options}
      />
    </Stack.Navigator>
  );
};
const AppNavigator = () => {
  return (
    <NavigationContainer>
      <RootNavigator />
    </NavigationContainer>
  );
};

export default AppNavigator;
