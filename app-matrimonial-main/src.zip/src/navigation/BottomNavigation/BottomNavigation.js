import {View, Text} from 'react-native';
import React from 'react';
import {
  BottomTabBar,
  createBottomTabNavigator,
} from '@react-navigation/bottom-tabs';
import HomePage from '../../screens/Main/HomePage/HomePage';
import PartnerMatch from '../../screens/Main/ParterMatch/PartnerMatch';
import NotificationScreen from '../../screens/Main/NotificationScreen/NotificationScreen';
import {NavigationContainer} from '@react-navigation/native';
import UserDetailsScreen from '../../screens/Main/UserDetailsScreen/UserDetailsScreen';
import {COLORS} from '../../assets/theme';
import {Fonts} from '../../assets/fonts';
import Icon from '../../components/Icon/Icon';
import {SVG} from '../../assets/svg';
import ProfileUpdateScreen from '../../screens/Main/ProfileUpdateScreen/ProfileUpdateScreen';
import {InboxScreen} from '../../screens';

const Tab = createBottomTabNavigator();
const BottomNavigation = () => {
  return (
    <Tab.Navigator
      screenOptions={({route}) => ({
        tabBarActiveTintColor: COLORS.dark.primary,
        tabBarInactiveTintColor: COLORS.dark.inputBorder,
        headerShown: false,
        tabBarItemStyle: {
          backgroundColor: 'white',
        },
        tabBarLabelPosition: 'below-icon',
        tabBarIcon: ({color}) => {
          if (route.name === 'HomePage') {
            return <Icon SVGIcon={<SVG.homeIcon fill={color} />} />;
          }
          if (route.name === 'PartnerMatch') {
            return <Icon SVGIcon={<SVG.heartIcon fill={color} />} />;
          }
          if (route.name === 'InboxScreen') {
            return <Icon SVGIcon={<SVG.envelopeIcon fill={color} />} />;
          }
          if (route.name === 'NotificationScreen') {
            return <Icon SVGIcon={<SVG.bell fill={color} />} />;
          }
          if (route.name === 'ProfileUpdateScreen') {
            return <Icon SVGIcon={<SVG.userIcon fill={color} />} />;
          }
        },
        tabBarStyle: {
          alignItems: 'center',
          justifyContent: 'center',
          height: 70, // Adjust the height according to your preference
          backgroundColor: 'white', // Tab bar background color
        },
        labelStyle: {
          fontFamily: Fonts.PoppinsRegular, // Specify your font family
          fontSize: 12, // Adjust the font size according to your preference
          marginTop: 5, // Adjust the margin between icon and label according to your preference
        },
      })}>
      <Tab.Screen
        name="HomePage"
        component={HomePage}
        options={{
          tabBarLabel: 'Home',
          tabBarActiveBackgroundColor: 'yellow',
        }}
      />
      <Tab.Screen
        name="PartnerMatch"
        component={PartnerMatch}
        options={{tabBarLabel: 'Matches'}}
      />
      <Tab.Screen
        name="InboxScreen"
        component={InboxScreen}
        options={{tabBarLabel: 'Inbox'}}
      />
      <Tab.Screen
        name="NotificationScreen"
        component={NotificationScreen}
        options={{tabBarLabel: 'Notification'}}
      />
      <Tab.Screen
        name="ProfileUpdateScreen"
        component={ProfileUpdateScreen}
        options={{tabBarLabel: 'Profile'}}
      />
    </Tab.Navigator>
  );
};

export default BottomNavigation;

// import React from 'react';
// import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
// import HomePage from '../../screens';
// import PartnerMatch from '../../screens';
// import NotificationScreen from '../../screens';
// import InboxScreen from '../../screens';
// import ProfileUpdateScreen from '../../screens';
// import CustomTabBar from './CustomTabBar/CustomtabBar';

// const Tab = createBottomTabNavigator();

// const BottomNavigation = () => {
//   return (
//     <Tab.Navigator tabBar={props => <CustomTabBar {...props} />}>
//       <Tab.Screen
//         name="HomePage"
//         component={HomePage}
//         options={{tabBarLabel: 'Home'}}
//       />
//       <Tab.Screen
//         name="PartnerMatch"
//         component={PartnerMatch}
//         options={{tabBarLabel: 'Matches'}}
//       />
//       <Tab.Screen
//         name="InboxScreen"
//         component={InboxScreen}
//         options={{tabBarLabel: 'Inbox'}}
//       />
//       <Tab.Screen
//         name="NotificationScreen"
//         component={NotificationScreen}
//         options={{tabBarLabel: 'Notification'}}
//       />
//       <Tab.Screen
//         name="ProfileUpdateScreen"
//         component={ProfileUpdateScreen}
//         options={{tabBarLabel: 'Profile'}}
//       />
//     </Tab.Navigator>
//   );
// };

// export default BottomNavigation;
