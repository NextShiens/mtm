// import React from 'react';
// import { View, TouchableOpacity, Text } from 'react-native';
// import { SVG } from '../../assets/svg'; 
// import { COLORS } from '../../assets/theme';
// import { Fonts } from '../../assets/fonts';

// const CustomTabBar = ({ state, descriptors, navigation }) => {
//   return (
//     <View style={{ flexDirection: 'row', height: 70, backgroundColor: 'white' }}>
//       {state.routes.map((route, index) => {
//         const { options } = descriptors[route.key];
//         const label = options.tabBarLabel || route.name;

//         const isFocused = state.index === index;

//         const onPress = () => {
//           const event = navigation.emit({
//             type: 'tabPress',
//             target: route.key,
//             canPreventDefault: true,
//           });

//           if (!isFocused && !event.defaultPrevented) {
//             navigation.navigate(route.name);
//           }
//         };

//         let icon;

//         if (route.name === 'HomePage') {
//           icon = <SVG.homeIcon fill={isFocused ? COLORS.dark.primary : COLORS.dark.inputBorder} />;
//         } else if (route.name === 'PartnerMatch') {
//           icon = <SVG.heartIcon fill={isFocused ? COLORS.dark.primary : COLORS.dark.inputBorder} />;
//         } else if (route.name === 'InboxScreen') {
//           icon = <SVG.envelopeIcon fill={isFocused ? COLORS.dark.primary : COLORS.dark.inputBorder} />;
//         } else if (route.name === 'NotificationScreen') {
//           icon = <SVG.bell fill={isFocused ? COLORS.dark.primary : COLORS.dark.inputBorder} />;
//         } else if (route.name === 'ProfileUpdateScreen') {
//           icon = <SVG.userIcon fill={isFocused ? COLORS.dark.primary : COLORS.dark.inputBorder} />;
//         }

//         return (
//           <TouchableOpacity
//             key={route.key}
//             onPress={onPress}
//             style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}
//           >
//             {icon}
//             <Text style={{ color: isFocused ? COLORS.dark.primary : COLORS.dark.inputBorder, marginTop: 5, fontFamily: Fonts.PoppinsRegular, fontSize: 12 }}>
//               {label}
//             </Text>
//           </TouchableOpacity>
//         );
//       })}
//     </View>
//   );
// };

// export default CustomTabBar;
