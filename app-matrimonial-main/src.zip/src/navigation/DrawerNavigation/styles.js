import {StyleSheet} from 'react-native';
export const styles = () =>
  StyleSheet.create({
    contentContainer: () => ({
      height: 80,
      paddingHorizontal: 15,
      flexDirection: 'row',
      paddingVertical: 15,
      justifyContent: 'space-between',
      alignItems: 'center',
      //   width: '100%',
    }),
    avatarContainer: () => ({
      position: 'relative',
      marginLeft: 10,
      width: 50,
      height: 50,
      borderRadius: 32,
      backgroundColor: '#007bff',
      alignItems: 'center',
      justifyContent: 'center',
    }),
    onlineDot: () => ({
      position: 'absolute',
      bottom: 0,
      right: 0,
      width: 12,
      height: 12,
      borderRadius: 6,
      backgroundColor: '#3EB115',
      borderWidth: 2,
      borderColor: '#ffffff',
    }),
    nameHolder: () => ({
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
    }),
    drawerItem: () => ({
      height: 80,
      flexDirection: 'row',
      alignItems: 'center',
      //   backgroundColor: '#DDDFEA',
      //   borderRadius: 10,
      marginHorizontal: 10,
      paddingHorizontal: 10,
    }),
    drawerItemText: () => ({
      marginLeft: 16,
      fontSize: 16,
    }),
    drawerContentContainer: () => ({}),
    activeDrawerItem: () => ({
      backgroundColor: '#DDDFEA',
      borderRadius: 10,
    }),
  });
