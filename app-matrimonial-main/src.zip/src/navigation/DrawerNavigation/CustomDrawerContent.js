import React, {useState} from 'react';
import {
  View,
  Text,
  ScrollView,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
import {styles} from './styles';
import {
  DrawerContentScrollView,
  DrawerItemList,
} from '@react-navigation/drawer';
import AppLogo from '../../components/AppLogo/AppLogo';
import CustomImage from '../../components/CustomImage/CustomImage';
import {IMAGES} from '../../assets/images';
import AppText from '../../components/AppText/AppText';
import {LABELS} from '../../labels';
import Icon from '../../components/Icon/Icon';
import {SVG} from '../../assets/svg';
import Space from '../../components/Space/Space';
import {Fonts} from '../../assets/fonts';
import {COLORS} from '../../assets/theme';
import {DrawerListData} from '../../data/appData';

const CustomDrawerContent = props => {
  const [isOnline, setIsOnline] = useState(true);
  const [drawerData, setDrawerData] = useState(DrawerListData);
  const style = styles();
  const windowWidth = Dimensions.get('window').width;
  const drawerWidth = windowWidth * 0.8;
  const focusedStyle = {
    backgroundColor: COLORS.dark.drawerTint,
    borderRadius: 10,
  };
  const getItemDetails = route => {
    console.log(route);
  };
  const handleItemClick = item => {
    item.onClick(setDrawerData);
    getItemDetails(item);
  };
  return (
    <View style={{flex: 1, width: drawerWidth}}>
      <DrawerContentScrollView {...props}>
        <View style={style.contentContainer()}>
          <View style={style.nameHolder()}>
            <View style={style.avatarContainer()}>
              <CustomImage
                source={IMAGES.profileAvatar}
                size={50}
                extraStyle={{container: {borderRadius: 25}}}
              />
              {isOnline && <View style={style.onlineDot()}></View>}
            </View>
            <Space mL={10} />
            <View style={{height: 25, marginBottom: 10}}>
              <AppText
                title={LABELS.exampleName}
                variant={'h4'}
                extraStyle={{fontFamily: Fonts.PoppinsSemiBold}}
              />
              <AppText
                title={LABELS.businessMan}
                color={COLORS.dark.inputBorder}
              />
            </View>
          </View>

          <TouchableOpacity
            onPress={() => {
              console.log('hello');
            }}>
            <Icon
              SVGIcon={
                <SVG.vectorIcon
                  fill={'black'}
                  height={20}
                  width={20}
                  onPress={() => {
                    console.log('hello2');
                  }}
                />
              }
            />
          </TouchableOpacity>
        </View>

        {DrawerListData.map(route => {
          if (route.name === 'Home') {
            return null;
          }
          const itemStyle = route.isActive
            ? style.activeDrawerItem()
            : style.drawerItem();

          return (
            <TouchableOpacity
              key={route.key}
              style={style.drawerItem()}
              onPress={() => {
                handleItemClick(route);
              }}>
              <CustomImage
                source={route.iconName}
                size={20}
                resizeMode={'contain'}
              />
              <Space mL={5} />
              <View style={{maxWidth: '80%'}}>
                <AppText
                  title={route.name}
                  variant={'h5'}
                  extraStyle={{fontFamily: Fonts.PoppinsMedium}}
                  color={COLORS.dark.black}
                />
                <AppText
                  title={route.description}
                  variant={'h6'}
                  color={COLORS.dark.inputBorder}
                />
              </View>
            </TouchableOpacity>
          );
        })}
      </DrawerContentScrollView>
    </View>
  );
};

export default CustomDrawerContent;
