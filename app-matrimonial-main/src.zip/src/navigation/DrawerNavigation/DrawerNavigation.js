import React from 'react';
import {createDrawerNavigator} from '@react-navigation/drawer';
import AccountsSetting from '../../screens/Main/AccountsSetting/AccountsSetting';
import MembershipPlan from '../../screens/Main/MembershipPlan/MembershipPlan';
import PaymentScreen from '../../screens/Main/PaymentScreen/PaymentScreen';
import UserPrivacyScreen from '../../screens/Main/UserPrivacyScreen/UserPrivacyScreen';
import BottomNavigation from '../BottomNavigation/BottomNavigation';
import CustomDrawerContent from './CustomDrawerContent';
import {ProfessionPreferenceScreen} from '../../screens';

const Drawer = createDrawerNavigator();
const DrawerNavigation = () => {
  return (
    <>
      <Drawer.Navigator
        initialRouteName="BottomNavigation"
        screenOptions={{
          headerShown: false,
        }}
        drawerContent={props => <CustomDrawerContent {...props} />}>
        <Drawer.Screen name="Home" component={BottomNavigation} />
        <Drawer.Screen name="AccountSetting" component={AccountsSetting} />
        <Drawer.Screen
          name="ProfessionPreferenceScreen"
          component={ProfessionPreferenceScreen}
        />
        <Drawer.Screen name="MembershipPlan" component={MembershipPlan} />
        <Drawer.Screen name="PaymentScreen" component={PaymentScreen} />
        <Drawer.Screen name="UserPrivacyScreen" component={UserPrivacyScreen} />
      </Drawer.Navigator>
    </>
  );
};

export default DrawerNavigation;
