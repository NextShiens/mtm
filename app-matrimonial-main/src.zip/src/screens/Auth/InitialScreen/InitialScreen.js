import React from 'react';
import {ImageBackground, StyleSheet, View} from 'react-native';
import AppButton from '../../../components/AppButton/AppButton';
import Space from '../../../components/Space/Space';
import {IMAGES} from '../../../assets/images';
import {LABELS} from '../../../labels';
import CustomImage from '../../../components/CustomImage/CustomImage';
import AppText from '../../../components/AppText/AppText';
import {Fonts} from '../../../assets/fonts';
import {styles as styling} from './styles';
import {useNavigation} from '@react-navigation/native';

const InitialScreen = () => {
  const styles = styling;
  const navigation = useNavigation();

  const signUpNavigation = () => {
    navigation.navigate('RegisterScreen');
  };
  const loginNavigation = () => {
    navigation.navigate('LoginScreen');
  };
  return (
    <View style={styles.container}>
      <ImageBackground
        source={IMAGES.initialBackground}
        resizeMode="cover"
        style={styles.image}>
        <ImageBackground
          source={IMAGES.gradientBg}
          resizeMode="cover"
          style={styles.image}>
          <View style={styles.contentContainer}>
            <View style={{alignSelf: 'center'}}>
              <CustomImage
                source={IMAGES.initialLogo}
                size={180}
                resizeMode={'contain'}
              />
              <AppText
                title={LABELS.initialMessage}
                alignSelf={'center'}
                color={'white'}
                variant={'h5'}
                extraStyle={{fontFamily: Fonts.PoppinsRegular}}
              />
              <AppText
                title={LABELS.continueInitialMsg}
                alignSelf={'center'}
                color={'white'}
                variant={'h5'}
                extraStyle={{fontFamily: Fonts.PoppinsRegular}}
              />
            </View>
            <Space mT={20} />
            <AppButton
              title={LABELS.createAccount}
              variant="filled"
              textVariant={'h5'}
              onPress={signUpNavigation}
              onPressText={signUpNavigation}
            />
            <Space mT={20} />
            <AppButton
              title={LABELS.login}
              variant="outlined"
              textVariant={'h5'}
              onPress={loginNavigation}
              onPressText={loginNavigation}
            />
            <Space mB={20} />
          </View>
        </ImageBackground>
      </ImageBackground>
    </View>
  );
};

export default InitialScreen;
