import React, {useState} from 'react';
import AppText from '../../../components/AppText/AppText';
import {View, ScrollView, TouchableOpacity} from 'react-native';
import LayoutImage from '../../../components/LayoutImage/LayoutImage';
import {IMAGES} from '../../../assets/images';
import AppHeader from '../../../components/AppHeader/AppHeader';
import {SVG} from '../../../assets/svg';
import AppLogo from '../../../components/AppLogo/AppLogo';
import {styles} from './styles';
import {LABELS} from '../../../labels';
import Space from '../../../components/Space/Space';
import {Fonts} from '../../../assets/fonts';
import {COLORS, HORIZON_MARGIN, STYLES} from '../../../assets/theme';
import AppInput from '../../../components/AppInput/AppInput';
import AppButton from '../../../components/AppButton/AppButton';
import CustomCheckbox from '../../../libraries/Checkbox/Checkbox';
import {useNavigation} from '@react-navigation/native';
import SocialAuth from '../../../components/SocialAuth/SocialAuth';
import CustomCountryPicker from '../../../libraries/CountryPicker/CountryPicker';
const LoginScreen = () => {
  const [isChecked, setIsChecked] = useState(false);
  const [countryCallingCode, setCountryCallingCode] = useState('');
  const [selectedCountry, setSelectedCountry] = useState(null);
  const [phone, setPhone] = useState(null);
  const navigation = useNavigation();
  const style = styles();

  const toggleCheckbox = () => {
    setIsChecked(!isChecked);
  };
  const backNavigationHandler = () => {
    navigation.goBack();
  };
  const registerationHandler = () => {
    navigation.navigate('OTPScreen');
  };
  const onTextEnter = () => {
    console.log('value entered');
  };
  const loginNavigationHandler = () => {
    navigation.navigate('InitialScreen');
  };
  const facebookAuthHandler = () => {
    console.log('login with facebook');
  };
  const appleAuthHandler = () => {
    console.log('login with apple');
  };

  const googleAuthHandler = () => {
    console.log('login with google');
  };
  const forgotPassHandler = () => {
    console.log('forgot password');
  };
  const countrySelectionHandler = country => {
    setCountryCallingCode(country.callingCode);
    setSelectedCountry(country.name);
    console.log(country);
  };
  const contactEntryHandler = val => {
    console.log(val);
  };
  return (
    <ScrollView style={{backgroundColor: 'white'}}>
      <View style={[style.container()]}>
        <LayoutImage imgSrc={IMAGES.theme2} />
        <AppHeader
          iconLeft={<SVG.BackArrow fill={'black'} />}
          extraStyle={{container: {position: 'absolute'}}}
          onLeftIconPress={backNavigationHandler}
        />

        <View style={[style.contentContainer()]}>
          <AppLogo extraStyle={{container: {bottom: '10%'}}} />
          <View style={[style.formContainer()]}>
            <AppText
              title={LABELS.welcomeBack}
              variant={'h2'}
              extraStyle={[
                STYLES.fontSize(22),
                {fontFamily: Fonts.PoppinsSemiBold},
              ]}
              alignSelf={'center'}
            />

            <AppText
              title={LABELS.loginMessage}
              variant={'h5'}
              extraStyle={[{fontFamily: Fonts.PoppinsRegular}]}
              alignSelf={'center'}
              color={COLORS.dark.gray}
            />

            <Space mT={10} />

            <AppText
              title={LABELS.emailAddress}
              variant={'h5'}
              extraStyle={[{fontFamily: Fonts.PoppinsRegular}]}
              alignSelf={'flex-start'}
              color={COLORS.dark.black}
            />
            <Space mT={10} />

            <AppInput placeholder={LABELS.emailPlaceholder} />

            <Space mT={10} />

            <AppText
              title={LABELS.phoneNumber}
              variant={'h5'}
              extraStyle={[{fontFamily: Fonts.PoppinsRegular}]}
              alignSelf={'flex-start'}
              color={COLORS.dark.black}
            />
            <Space mT={10} />

            <View style={style.countrySelectContainer()}>
              <CustomCountryPicker
                onCountrySelect={countrySelectionHandler}
                placeholder={countryCallingCode}
                onContactEnter={contactEntryHandler}
              />
              <AppInput
                keyboardType="numeric"
                extraStyle={{
                  textInput: {
                    alignItems: 'center',
                    justifyContent: 'center',
                  },
                  textInputCont: {
                    borderColor: COLORS.dark.transparent,
                    justifyContent: 'center',
                  },
                }}
                placeholder={LABELS.phonePlaceholder}
                onChangeText={val => {
                  console.log(val);
                }}
              />
            </View>

            {/* <AppInput
              placeholder={LABELS.phonePlaceholder}
              keyboardType={'numeric'}
              onChangeText={onTextEnter}
            /> */}
            <Space mT={10} />

            <View style={[STYLES.row]}>
              <CustomCheckbox selected={isChecked} onPress={toggleCheckbox} />
              <View style={[STYLES.rowCenterBt, {width: '92%'}]}>
                <AppText
                  title={LABELS.rememberMe}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                  color={COLORS.dark.checkboxText}
                />
                <TouchableOpacity onPress={forgotPassHandler}>
                  <AppText
                    title={LABELS.forgotPass}
                    extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                    color={COLORS.dark.black}
                    onPress={forgotPassHandler}
                  />
                </TouchableOpacity>
              </View>
            </View>
            <Space mT={20} />

            <AppButton
              title={LABELS.createAccount}
              variant="filled"
              textVariant={'h5'}
              onPress={registerationHandler}
            />
            <Space mT={20} />

            <View style={style.hrContainer()}>
              <View style={style.hr()}></View>
              <AppText
                title={LABELS.continueWith}
                extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                color={COLORS.dark.black}
                variant={'h5'}
              />
              <View style={style.hr()}></View>
            </View>
            <Space mT={30} />

            <SocialAuth
              onFacebookAuth={facebookAuthHandler}
              onGoogleAuth={googleAuthHandler}
              onAppleAuth={appleAuthHandler}
            />
            <Space mT={20} />
            <View style={[STYLES.rowCenter, STYLES.JCCenter]}>
              <AppText
                title={LABELS.alreadyHaveAccount}
                extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                color={COLORS.dark.black}
              />
              <AppText
                title={LABELS.signIn}
                extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                color={COLORS.dark.primary}
                variant={'h5'}
                onPress={loginNavigationHandler}
              />
            </View>
          </View>
        </View>
      </View>
    </ScrollView>
  );
};

export default LoginScreen;
