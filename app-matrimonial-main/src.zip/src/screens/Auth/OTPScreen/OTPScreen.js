import React, {useState} from 'react';
import AppText from '../../../components/AppText/AppText';
import {View, ScrollView, TouchableOpacity} from 'react-native';
import LayoutImage from '../../../components/LayoutImage/LayoutImage';
import {IMAGES} from '../../../assets/images';
import AppHeader from '../../../components/AppHeader/AppHeader';
import {SVG} from '../../../assets/svg';
import AppLogo from '../../../components/AppLogo/AppLogo';
import {styles} from './styles';
import {LABELS} from '../../../labels';
import Space from '../../../components/Space/Space';
import {Fonts} from '../../../assets/fonts';
import {COLORS, HORIZON_MARGIN, STYLES} from '../../../assets/theme';
import AppButton from '../../../components/AppButton/AppButton';
import {useNavigation} from '@react-navigation/native';
import OTPTextInput from '../../../libraries/OTPTextInput/OTPTextInput';

const OTPScreen = () => {
  const [otp, setOtp] = useState(['', '', '', '']);
  const navigation = useNavigation();
  const style = styles();

  const handleInputChange = (index, text) => {
    const updatedOTP = [...otp];
    updatedOTP[index] = text;
    setOtp(updatedOTP);
  };

  const handleSubmit = () => {
    const enteredOTP = otp.join('');
    // Add your OTP verification logic here
    console.log('Entered OTP:', enteredOTP);
    navigation.navigate('ProfileCreateScreen');
  };

  const resendCodeHandler = () => {
    console.log('Resend Code');
  };
  const backNavigationHandler = () => {
    navigation.goBack();
  };

  return (
    <ScrollView style={{backgroundColor: 'white'}}>
      <View style={[style.container()]}>
        <LayoutImage imgSrc={IMAGES.theme2} />
        <AppHeader
          iconLeft={<SVG.BackArrow fill={'black'} />}
          extraStyle={{container: {position: 'absolute'}}}
          onLeftIconPress={backNavigationHandler}
        />

        <View style={[style.contentContainer()]}>
          <AppLogo extraStyle={{container: {bottom: '10%'}}} />
          <View style={[style.formContainer()]}>
            <AppText
              title={LABELS.enterVeification}
              variant={'h2'}
              extraStyle={[
                STYLES.fontSize(22),
                {fontFamily: Fonts.PoppinsSemiBold},
              ]}
              alignSelf={'center'}
            />

            <AppText
              title={LABELS.verificationMsg}
              variant={'h5'}
              extraStyle={[{fontFamily: Fonts.PoppinsRegular}]}
              alignSelf={'center'}
              color={COLORS.dark.gray}
            />

            <Space mT={20} />
            <OTPTextInput
              length={4}
              onChangeText={handleInputChange}
              value={otp}
            />

            <Space mT={20} />
            <AppButton
              title={LABELS.createAccount}
              variant="filled"
              textVariant={'h5'}
              onPress={handleSubmit}
            />
            <Space mT={20} />
            <AppText
              title={LABELS.resendCode}
              extraStyle={{fontFamily: Fonts.PoppinsMedium}}
              variant={'h5'}
              color={COLORS.dark.primary}
              alignSelf={'center'}
              onPress={resendCodeHandler}
            />
          </View>
        </View>
      </View>
    </ScrollView>
  );
};

export default OTPScreen;
