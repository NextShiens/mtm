import React from 'react';
import {Text, View, TouchableOpacity, ScrollView} from 'react-native';
import AppHeader from '../../../components/AppHeader/AppHeader';
import {SVG} from '../../../assets/svg';
import {LABELS} from '../../../labels';
import {IMAGES} from '../../../assets/images';
import CustomImage from '../../../components/CustomImage/CustomImage';
import {styles} from './styles';
import AppText from '../../../components/AppText/AppText';
import Space from '../../../components/Space/Space';
import {Fonts} from '../../../assets/fonts';
import UserDetailsCard from '../../../components/UserDetailsCard/UserDetailsCard';
import {COLORS} from '../../../assets/theme';
import {
  preferDetails,
} from '../../../data/appData';
import AppButton from '../../../components/AppButton/AppButton';

const PartnerReferenceScreen = ({navigation}) => {
  const style = styles();
  const backNavigationHandler = () => {
    navigation.goBack();
  };
  const nextPageNavigationHandler = () => {
    navigation.navigate('PartnerMatch');
  };
  return (
    <ScrollView>
      <View style={style.container()}>
        <View style={style.headerContainer()}>
          <AppHeader
            iconLeft={<SVG.BackArrow fill={'black'} />}
            onLeftIconPress={backNavigationHandler}
            title={LABELS.partnerPreference}
            iconRight={
              <CustomImage
                source={IMAGES.notificationIcon}
                size={27}
                resizeMode={'contain'}
              />
            }
          />
        </View>
        <Space mT={20} />
        <View style={style.contentContainer()}>
          <AppText
            title={LABELS.match}
            variant={'h4'}
            extraStyle={{
              fontFamily: Fonts.PoppinsMedium,
            }}
          />
          <Space mT={20} />

          <View style={style.userCardContainer()}>
            <View style={style.userCardSubContainer()}>
              <TouchableOpacity
                style={style.TouchableContainer()}
                onPress={() => {
                  console.log('age pressed');
                }}>
                <AppText
                  title={LABELS.age}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                  variant={'h5'}
                />

                <CustomImage
                  source={IMAGES.arrowIcon}
                  size={12}
                  resizeMode={'contain'}
                />
              </TouchableOpacity>
            </View>

            <View style={style.hr()}></View>
            <View style={style.userCardSubContainer()}>
              <TouchableOpacity
                style={style.TouchableContainer()}
                onPress={() => {
                  console.log('partner marital status ');
                }}>
                <AppText
                  title={LABELS.maritalStatus}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                  variant={'h5'}
                />
                <CustomImage
                  source={IMAGES.arrowIcon}
                  size={12}
                  resizeMode={'contain'}
                />
              </TouchableOpacity>
            </View>
          </View>
          <Space mT={15} />
          <AppText
            title={LABELS.contentPartnerPreference}
            alignSelf={'center'}
            variant={'h6'}
            color={COLORS.dark.gray}
            extraStyle={{fontFamily: Fonts.PoppinsRegular}}
          />
          <Space mT={10} />
          <AppText
            title={LABELS.addMore}
            variant={'h4'}
            extraStyle={{
              fontFamily: Fonts.PoppinsMedium,
            }}
          />
          <Space mT={20} />
          <View style={style.userCardContainer()}>
            <UserDetailsCard data={preferDetails} />
          </View>
          <Space mT={20} />
          <AppButton
            variant="filled"
            title={LABELS.save}
            extraStyle={{
              text: {
                fontFamily: Fonts.PoppinsMedium,
              },
            }}
            textVariant={'h5'}
            onPress={nextPageNavigationHandler}
          />
          <Space mT={20} />
        </View>
      </View>
    </ScrollView>
  );
};

export default PartnerReferenceScreen;
