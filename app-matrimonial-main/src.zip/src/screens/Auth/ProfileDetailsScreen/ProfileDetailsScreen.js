import React, {useState} from 'react';
import AppText from '../../../components/AppText/AppText';
import {View, ScrollView} from 'react-native';
import LayoutImage from '../../../components/LayoutImage/LayoutImage';
import {IMAGES} from '../../../assets/images';
import AppHeader from '../../../components/AppHeader/AppHeader';
import {SVG} from '../../../assets/svg';
import AppLogo from '../../../components/AppLogo/AppLogo';
import {styles} from './styles';
import {LABELS} from '../../../labels';
import Space from '../../../components/Space/Space';
import {Fonts} from '../../../assets/fonts';
import {COLORS, STYLES} from '../../../assets/theme';
import AppInput from '../../../components/AppInput/AppInput';
import AppButton from '../../../components/AppButton/AppButton';
import {useNavigation} from '@react-navigation/native';
import CustomDropdown from '../../../libraries/Dropdown/Dropdown';
import {
  QualificationList,
  annualIncomeList,
  occupationList,
  workLocationList,
} from '../../../data/appData';
const ProfileDetailsScreen = () => {
  const navigation = useNavigation();

  const style = styles();

  const backNavigationHandler = () => {
    navigation.goBack();
  };
  const navigationHandler = () => {
    navigation.navigate('PartnerReferenceScreen');
  };
  const onTextEnter = () => {
    console.log('value entered');
  };
  const onEducationSelect = val => {
    console.log(val);
  };
  const onWorkLocationSelect = val => {
    console.log('work location', val);
  };
  return (
    <ScrollView style={{backgroundColor: 'white'}}>
      <View style={[style.container()]}>
        <LayoutImage imgSrc={IMAGES.theme2} />
        <AppHeader
          iconLeft={<SVG.BackArrow fill={'black'} />}
          extraStyle={{container: {position: 'absolute'}}}
          onLeftIconPress={backNavigationHandler}
        />
        <View style={[style.contentContainer()]}>
          <AppLogo extraStyle={{container: {bottom: '10%'}}} />
          <View style={[style.formContainer()]}>
            <AppText
              title={LABELS.profileCreation}
              variant={'h2'}
              extraStyle={[
                STYLES.fontSize(22),
                {fontFamily: Fonts.PoppinsSemiBold},
              ]}
              alignSelf={'center'}
            />

            <AppText
              title={LABELS.profileCreateMsg}
              variant={'h5'}
              extraStyle={[{fontFamily: Fonts.PoppinsRegular}]}
              alignSelf={'center'}
              color={COLORS.dark.gray}
            />
            <Space mT={20} />

            <AppText
              title={LABELS.highestDegree}
              variant={'h5'}
              extraStyle={[{fontFamily: Fonts.PoppinsRegular}]}
              alignSelf={'flex-start'}
              color={COLORS.dark.black}
            />
            <Space mT={10} />

            <CustomDropdown
              data={QualificationList}
              placeholder={LABELS.select}
              setSelected={onEducationSelect}
              onSelect={onEducationSelect}
              search={false}
            />

            <Space mT={20} />

            <AppText
              title={LABELS.occupation}
              variant={'h5'}
              extraStyle={[{fontFamily: Fonts.PoppinsRegular}]}
              alignSelf={'flex-start'}
              color={COLORS.dark.black}
            />
            <Space mT={10} />
            <CustomDropdown
              data={occupationList}
              placeholder={LABELS.select}
              setSelected={onEducationSelect}
              onSelect={onEducationSelect}
              search={false}
            />
            <Space mT={10} />

            <AppText
              title={LABELS.employIn}
              variant={'h5'}
              extraStyle={[{fontFamily: Fonts.PoppinsRegular}]}
              alignSelf={'flex-start'}
              color={COLORS.dark.black}
            />
            <Space mT={10} />

            <AppInput
              placeholder={LABELS.employePlaceholder}
              onChangeText={onTextEnter}
              keyboardType={'default'}
            />
            <Space mT={10} />

            <AppText
              title={LABELS.AnnualIncome}
              variant={'h5'}
              extraStyle={[{fontFamily: Fonts.PoppinsRegular}]}
              alignSelf={'flex-start'}
              color={COLORS.dark.black}
            />
            <Space mT={10} />

            <CustomDropdown
              data={annualIncomeList}
              placeholder={LABELS.incomePlaceholder}
            />
            <Space mT={15} />

            <AppText
              title={LABELS.workLocation}
              variant={'h5'}
              extraStyle={[{fontFamily: Fonts.PoppinsRegular}]}
              alignSelf={'flex-start'}
              color={COLORS.dark.black}
            />
            <Space mT={10} />

            <CustomDropdown
              placeholder={LABELS.workLocationPlaceholder}
              data={workLocationList}
              setSelected={onWorkLocationSelect}
            />

            <Space mT={20} />
            <AppButton
              title={LABELS.continue}
              variant="filled"
              textVariant={'h5'}
              onPress={navigationHandler}
            />
          </View>
        </View>
      </View>
    </ScrollView>
  );
};

export default ProfileDetailsScreen;
