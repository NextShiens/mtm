import {View, Text, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import AppHeader from '../../../components/AppHeader/AppHeader';
import {SVG} from '../../../assets/svg';
import {LABELS} from '../../../labels';
import {IMAGES} from '../../../assets/images';
import CustomImage from '../../../components/CustomImage/CustomImage';
import ProfileSelector from '../../../components/ProfileSelector/ProfileSelector';
import {connectionChat, connectionStatus, inboxData} from '../../../data/appData';
import Space from '../../../components/Space/Space';
import ConnectionsInboxCard from '../../../components/ConnectionsInboxCard/ConnectionsInboxCard';
const AcceptedConnections = ({navigation}) => {
  const style = styles();
  const handleRightIconPress = () => {
    navigation.navigate('NotificationScreen');
  };
  return (
    <View>
      <View style={style.headerContainer()}>
        <AppHeader
          iconLeft={<SVG.BackArrow fill={'black'} />}
          onLeftIconPress={() => {
            navigation.goBack();
          }}
          title={LABELS.connection}
          iconRight={
            <TouchableOpacity onPress={handleRightIconPress}>
              <CustomImage
                source={IMAGES.notificationIcon}
                size={27}
                resizeMode={'contain'}
              />
            </TouchableOpacity>
          }
        />
      </View>
      <ProfileSelector profileData={connectionStatus} isCameraShown={false} />
      <Space mT={20} />
      <ConnectionsInboxCard data={connectionChat} />
    </View>
  );
};

export default AcceptedConnections;
