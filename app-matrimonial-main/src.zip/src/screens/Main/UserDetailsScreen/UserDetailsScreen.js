import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ImageBackground,
  ScrollView,
} from 'react-native';
import {styles} from './styles';
import AppHeader from '../../../components/AppHeader/AppHeader';
import {SVG} from '../../../assets/svg';
import {LABELS} from '../../../labels';
import CustomImage from '../../../components/CustomImage/CustomImage';
import {IMAGES} from '../../../assets/images';
import {COLORS, STYLES} from '../../../assets/theme';
import AppText from '../../../components/AppText/AppText';
import Space from '../../../components/Space/Space';
import {Fonts} from '../../../assets/fonts';

const UserDetailsScreen = () => {
  const style = styles();
  return (
    <ScrollView style={{flex: 1, backgroundColor: 'white'}}>
      <View style={style.container()}>
        <ImageBackground
          source={IMAGES.carousel1}
          style={style.carouselContainer()}>
          <AppHeader
            iconLeft={<SVG.BackArrow fill={'black'} />}
            iconRight={
              <>
                <TouchableOpacity style={style.rightIconContainer()}>
                  <CustomImage
                    source={IMAGES.savedIcon}
                    size={18}
                    resizeMode={'contain'}
                  />
                </TouchableOpacity>
              </>
            }
            title={LABELS.matches}
          />
        </ImageBackground>
        <View style={style.contentContainer()}>
          <View style={style.basicDetailsContainer()}>
            <Space mT={20} />
            <AppText
              title={LABELS.ShusmitaSharma}
              variant={'h3'}
              color={COLORS.dark.black}
              extraStyle={{fontFamily: Fonts.PoppinsSemiBold}}
            />
            <AppText
              title={LABELS.AssistantManager}
              variant={'h5'}
              color={COLORS.dark.inputBorder}
              extraStyle={{fontFamily: Fonts.PoppinsRegular}}
            />
            <Space mT={15} />
            <AppText
              title={LABELS.examplePara}
              variant={'h5'}
              color={COLORS.dark.black}
              extraStyle={{fontFamily: Fonts.PoppinsRegular}}
            />
            <Space mT={10} />
            <AppText
              title={LABELS.mumbaiIndia}
              variant={'h5'}
              color={COLORS.dark.inputBorder}
              extraStyle={{fontFamily: Fonts.PoppinsRegular}}
            />
            <Space mT={10} />
            <View style={style.hr()}></View>
            <Space mT={10} />
            <AppText
              title={LABELS.basicInfo}
              variant={'h3'}
              color={COLORS.dark.inputBorder}
              extraStyle={{fontFamily: Fonts.PoppinsSemiBold}}
            />
            <View style={style.basicInfoContainer()}>
              <View style={style.infoCont1()}>
                <AppText
                  title={LABELS.name}
                  variant={'h4'}
                  color={COLORS.dark.inputBorder}
                  extraStyle={{fontFamily: Fonts.PoppinsMedium}}
                />
                <AppText
                  title={LABELS.exampleName}
                  variant={'h5'}
                  color={COLORS.dark.black}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                />
                <Space mT={10} />

                <AppText
                  title={LABELS.maritalStatus}
                  variant={'h4'}
                  color={COLORS.dark.lightGrey}
                  extraStyle={{fontFamily: Fonts.PoppinsMedium}}
                />
                <AppText
                  title={LABELS.neverMarried}
                  variant={'h5'}
                  color={COLORS.dark.black}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                />

                <Space mT={10} />

                <AppText
                  title={LABELS.maritalStatus}
                  variant={'h4'}
                  color={COLORS.dark.lightGrey}
                  extraStyle={{fontFamily: Fonts.PoppinsMedium}}
                />
                <AppText
                  title={LABELS.neverMarried}
                  variant={'h5'}
                  color={COLORS.dark.black}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                />
                <Space mT={10} />
                <AppText
                  title={LABELS.maritalStatus}
                  variant={'h4'}
                  color={COLORS.dark.lightGrey}
                  extraStyle={{fontFamily: Fonts.PoppinsMedium}}
                />
                <AppText
                  title={LABELS.neverMarried}
                  variant={'h5'}
                  color={COLORS.dark.black}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                />
              </View>

              <View style={style.infoCont2()}>
                <AppText
                  title={LABELS.name}
                  variant={'h4'}
                  color={COLORS.dark.inputBorder}
                  extraStyle={{fontFamily: Fonts.PoppinsMedium}}
                />
                <AppText
                  title={LABELS.exampleName}
                  variant={'h5'}
                  color={COLORS.dark.black}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                />
                <Space mT={10} />

                <AppText
                  title={LABELS.maritalStatus}
                  variant={'h4'}
                  color={COLORS.dark.lightGrey}
                  extraStyle={{fontFamily: Fonts.PoppinsMedium}}
                />
                <AppText
                  title={LABELS.neverMarried}
                  variant={'h5'}
                  color={COLORS.dark.black}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                />

                <Space mT={10} />

                <AppText
                  title={LABELS.maritalStatus}
                  variant={'h4'}
                  color={COLORS.dark.lightGrey}
                  extraStyle={{fontFamily: Fonts.PoppinsMedium}}
                />
                <AppText
                  title={LABELS.neverMarried}
                  variant={'h5'}
                  color={COLORS.dark.black}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                />
                <Space mT={10} />
                <AppText
                  title={LABELS.maritalStatus}
                  variant={'h4'}
                  color={COLORS.dark.lightGrey}
                  extraStyle={{fontFamily: Fonts.PoppinsMedium}}
                />
                <AppText
                  title={LABELS.neverMarried}
                  variant={'h5'}
                  color={COLORS.dark.black}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                />
              </View>
            </View>
            <Space mT={10} />
            <View style={style.hr()}></View>
            <Space mT={10} />

            <View style={style.basicInfoContainer()}>
              <View style={style.infoCont1()}>
                <AppText
                  title={LABELS.name}
                  variant={'h4'}
                  color={COLORS.dark.inputBorder}
                  extraStyle={{fontFamily: Fonts.PoppinsMedium}}
                />
                <AppText
                  title={LABELS.exampleName}
                  variant={'h5'}
                  color={COLORS.dark.black}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                />
                <Space mT={10} />
                
              </View>

              <View style={style.infoCont2()}>
                <AppText
                  title={LABELS.name}
                  variant={'h4'}
                  color={COLORS.dark.inputBorder}
                  extraStyle={{fontFamily: Fonts.PoppinsMedium}}
                />
                <AppText
                  title={LABELS.exampleName}
                  variant={'h5'}
                  color={COLORS.dark.black}
                  extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                />
                <Space mT={10} />

              </View>


            </View>
          </View>
        </View>
      </View>
    </ScrollView>
  );
};

export default UserDetailsScreen;
