import {StyleSheet} from 'react-native';
import {COLORS, HORIZON_MARGIN} from '../../../assets/theme';
export const styles = () =>
  StyleSheet.create({
    container: () => ({
      flex: 1,
    }),
    rightIconContainer: () => ({
      height: 40,
      width: 40,
      justifyContent: 'center',
      alignItems: 'center',
      elevation: 5,
      backgroundColor: COLORS.dark.primary,
      borderRadius: 10,
    }),
    carouselContainer: () => ({
      height: 290,
      width: '100%',
      backgroundColor: 'red',
      position: 'relative',
    }),
    contentContainer: () => ({
      flex: 1,
      backgroundColor: COLORS.dark.white,
      borderTopLeftRadius: 15,
      borderTopRightRadius: 15,
      backgroundColor: COLORS.dark.white,
      bottom: 10,
    }),
    basicDetailsContainer: () => ({
      width: '100%',
      paddingHorizontal: HORIZON_MARGIN,
      justifyContent: 'center',
    }),
    hr: () => ({
      height: 1,
      width: '100%',
      alignSelf: 'center',
      backgroundColor: COLORS.dark.lightGrey,
    }),
    basicInfoContainer: () => ({
      width: '100%',
      flexDirection: 'row',
      justifyContent: 'space-between',
    }),
    infoCont1: () => ({
      width: '50%',
    }),
    infoCont2: () => ({
      width: '50%',
    }),
  });
