import {View, Text, ScrollView, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import AppHeader from '../../../components/AppHeader/AppHeader';
import {SVG} from '../../../assets/svg';
import {IMAGES} from '../../../assets/images';
import {LABELS} from '../../../labels';
import CustomImage from '../../../components/CustomImage/CustomImage';
import AppInput from '../../../components/AppInput/AppInput';
import {COLORS} from '../../../assets/theme';
import Space from '../../../components/Space/Space';
import InboxCard from '../../../components/InboxCard/InboxCard';
import {inboxData} from '../../../data/appData';

const InboxScreen = ({navigation}) => {
  const style = styles();
  const handleRightIconPress = () => {
    navigation.navigate('NotificationScreen');
  };
  return (
    <ScrollView >
      <View style={style.headerContainer()}>
        <AppHeader
          iconLeft={<SVG.BackArrow fill={'black'} />}
          onLeftIconPress={() => {
            navigation.goBack();
          }}
          title={LABELS.inbox}
          iconRight={
            <TouchableOpacity onPress={handleRightIconPress}>
              <CustomImage
                source={IMAGES.notificationIcon}
                size={27}
                resizeMode={'contain'}
              />
            </TouchableOpacity>
          }
        />
      </View>
      <Space mT={20} />
      <View style={style.searchBoxContainer()}>
        <AppInput
          iconLeft={<SVG.magnifyingGlass fill={'black'} />}
          extraStyle={{
            textInputCont: {
              width: '80%',
              backgroundColor: COLORS.dark.searchBox,
              borderWidth: 0,
            },
          }}
          placeholder={LABELS.searchHere}
          // onChangeText={handlesearchFunctionality}
        />
        <TouchableOpacity
          style={style.filterBtn()}
          activeOpacity={0.8}
          // onPress={handlesearchBtn}
        >
          <CustomImage
            source={IMAGES.filterIcon}
            size={17}
            resizeMode={'contain'}
          />
        </TouchableOpacity>
      </View>
      <Space mT={20} />
      <TouchableOpacity style={style.inboxContainer()}>
        <InboxCard data={inboxData} />
      </TouchableOpacity>
    </ScrollView>
  );
};

export default InboxScreen;
