import { View, Text } from 'react-native'
import React from 'react'

const UserPrivacyScreen = () => {
  return (
    <View>
      <Text>UserPrivacyScreen</Text>
    </View>
  )
}

export default UserPrivacyScreen