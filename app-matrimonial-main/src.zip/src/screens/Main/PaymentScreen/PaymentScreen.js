import { View, Text } from 'react-native'
import React from 'react'

const PaymentScreen = () => {
  return (
    <View>
      <Text>PaymentScreen</Text>
    </View>
  )
}

export default PaymentScreen