import {View, Text} from 'react-native';
import React from 'react';

const AccountsSetting = () => {
  return (
    <View>
      <Text>AccountsSetting</Text>
    </View>
  );
};

export default AccountsSetting;
