import {View, Text} from 'react-native';
import React, {useState} from 'react';
import AppHeader from '../../../components/AppHeader/AppHeader';
import {SVG} from '../../../assets/svg';
import {COLORS, HORIZON_MARGIN, STYLES} from '../../../assets/theme';
import CustomImage from '../../../components/CustomImage/CustomImage';
import {IMAGES} from '../../../assets/images';
import {LABELS} from '../../../labels';
import Space from '../../../components/Space/Space';
import ProfileSelector from '../../../components/ProfileSelector/ProfileSelector';
import {profilePictures, profileUpdateData} from '../../../data/appData';
import AppText from '../../../components/AppText/AppText';
import AppInput from '../../../components/AppInput/AppInput';
import {Fonts} from '../../../assets/fonts';
import CustomCountryCodePicker from '../../../libraries/CustomCountryCodePicker/CustomCountryCodePicker';
import {styles} from './styles';
import BirthDatePicker from '../../../libraries/DatePicker/DatePicker';

const ProfileUpdateScreen = ({navigation}) => {
  const [isChecked, setIsChecked] = useState(false);
  const [countryCode, setCountryCode] = useState('+91');
  const [countryShow, setCountryShow] = useState(false);
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState(new Date());
  const [phone, setPhone] = useState(null);
  const style = styles();
  const userData = {
    userName: 'John Smith',
    userEmail: 'John_Smith@gmail.com',
    phone: +919876543210,
    dateOfBirth: '01/01/1990',
  };
  const onTextEnter = () => {
    console.log('value entered');
  };
  const openCountryModal = () => {
    setCountryShow(true);
  };
  const closeCountryModal = () => {
    setCountryShow(false);
  };
  const onSelectCountry = item => {
    setCountryCode(item.dial_code);
    setCountryShow(false);
  };
  const onDateCancel = () => {
    setOpen(false);
  };
  const dateConfirmationHandler = date => {
    setOpen(false);
    setDate(date);
    console.log('selected date is', date);
  };
  const onDateOpen = () => {
    setOpen(true);
  };
  return (
    <View>
      <AppHeader
        iconLeft={<SVG.BackArrow fill={COLORS.dark.black} />}
        title={LABELS.profile}
        onLeftIconPress={() => {
          navigation.goBack();
        }}
        iconRight={
          <>
            <CustomImage
              source={IMAGES.notificationIcon}
              size={25}
              resizeMode="contain"
            />
          </>
        }
      />
      <Space mT={20} />
      <View>
        <ProfileSelector
          profiles={profilePictures}
          profileData={profileUpdateData}
          isCameraShown = {true}
        />
      </View>
      <Space mT={20} />

      <View style={[STYLES.pH(HORIZON_MARGIN)]}>
        <AppText
          title={LABELS.fullName}
          variant={'h5'}
          extraStyle={[{fontFamily: Fonts.PoppinsRegular}]}
          alignSelf={'flex-start'}
          color={COLORS.dark.black}
        />
        <Space mT={10} />

        <AppInput
          placeholder={LABELS.johnSmith}
          onChangeText={onTextEnter}
          placeholderTextColor={COLORS.dark.black}
        />

        <Space mT={10} />

        <AppText
          title={LABELS.emailAddress}
          variant={'h5'}
          extraStyle={[{fontFamily: Fonts.PoppinsRegular}]}
          alignSelf={'flex-start'}
          color={COLORS.dark.black}
        />
        <Space mT={10} />

        <AppInput
          placeholder={LABELS.emailPlaceholder}
          placeholderTextColor={COLORS.dark.black}
          onChangeText={onTextEnter}
        />

        <Space mT={10} />
        <AppText
          title={LABELS.phoneNumber}
          variant={'h5'}
          extraStyle={[{fontFamily: Fonts.PoppinsRegular}]}
          alignSelf={'flex-start'}
          color={COLORS.dark.black}
        />
        <Space mT={10} />

        <View style={style.countrySelectContainer()}>
          <CustomCountryCodePicker
            countryShow={countryShow}
            onOpen={openCountryModal}
            onClose={closeCountryModal}
            countryCode={countryCode}
            onSelectCountry={onSelectCountry}
          />
          <AppInput
            keyboardType="numeric"
            placeholderTextColor={COLORS.dark.black}
            extraStyle={{
              textInput: {
                alignItems: 'center',
                justifyContent: 'center',
              },
              textInputCont: {
                borderColor: COLORS.dark.transparent,
                justifyContent: 'center',
              },
            }}
            placeholder={LABELS.phonePlaceholder}
            onChangeText={val => {
              setPhone(val);
            }}
          />
        </View>

        <Space mT={10} />

        <AppText
          title={LABELS.dateOfBirth}
          variant={'h5'}
          extraStyle={[{fontFamily: Fonts.PoppinsRegular}]}
          alignSelf={'flex-start'}
          color={COLORS.dark.black}
          onPress={() => {
            setOpen(true);
          }}
        />
        <BirthDatePicker
          open={open}
          selectedDate={date}
          onConfirm={dateConfirmationHandler}
          onCancel={onDateCancel}
          onOpen={onDateOpen}
          placeholderColor={COLORS.dark.black}
        />
      </View>
    </View>
  );
};

export default ProfileUpdateScreen;
