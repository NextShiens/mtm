import {View, Text, ScrollView, TouchableOpacity} from 'react-native';
import React from 'react';
import AppHeader from '../../../components/AppHeader/AppHeader';
import {LABELS} from '../../../labels';
import {SVG} from '../../../assets/svg';
import CustomImage from '../../../components/CustomImage/CustomImage';
import {IMAGES} from '../../../assets/images';
import {COLORS, HORIZON_MARGIN, STYLES} from '../../../assets/theme';
import {styles} from './styles';
import AppInput from '../../../components/AppInput/AppInput';
import Space from '../../../components/Space/Space';
import FastImage from 'react-native-fast-image';
import {verticalCardData} from '../../../data/appData';
import AppText from '../../../components/AppText/AppText';
import {Fonts} from '../../../assets/fonts';
import LinearGradient from 'react-native-linear-gradient';

const PartnerMatch = ({navigation}) => {
  //handle right icon press
  const handleRightIconPress = () => {
    navigation.navigate('NotificationScreen');
  };
  //handle item press
  const handleLeftIconPress = () => {
    console.log('left icon pressed');
  };
  //handle search functionality
  const handlesearchFunctionality = item => {
    console.log('search functionality', item);
  };
  const handlesearchBtn = () => {
    console.log('search button pressed');
  };
  const style = styles();
  return (
    <>
      <ScrollView>
        <View style={style.headerContainer()}>
          <AppHeader
            iconLeft={<SVG.BackArrow fill={'black'} />}
            onLeftIconPress={() => {
              navigation.goBack();
            }}
            title={LABELS.matches}
            iconRight={
              <TouchableOpacity onPress={handleRightIconPress}>
                <CustomImage
                  source={IMAGES.notificationIcon}
                  size={27}
                  resizeMode={'contain'}
                />
              </TouchableOpacity>
            }
          />
        </View>
        <Space mT={20} />
        <View style={style.searchBoxContainer()}>
          <AppInput
            iconLeft={<SVG.magnifyingGlass fill={'black'} />}
            extraStyle={{
              textInputCont: {
                width: '80%',
                backgroundColor: COLORS.dark.searchBox,
                borderWidth: 0,
              },
            }}
            placeholder={LABELS.searchHere}
            onChangeText={handlesearchFunctionality}
          />
          <TouchableOpacity
            style={style.filterBtn()}
            activeOpacity={0.8}
            onPress={handlesearchBtn}>
            <CustomImage
              source={IMAGES.filterIcon}
              size={17}
              resizeMode={'contain'}
            />
          </TouchableOpacity>
        </View>

        <Space mT={20} />
        <View style={STYLES.pH(HORIZON_MARGIN)}>
          {verticalCardData ? (
            verticalCardData.map(item => {
              return (
                <View style={style.cardContainer()} key = {item.key}>
                  <View style={style.imgContainer()}>
                    <FastImage
                      source={item.profile}
                      resizeMode="cover"
                      style={style.img()}
                    />
                    <LinearGradient
                      colors={['transparent', COLORS.dark.secondary]}
                      style={style.gradientOverlay()}
                    />
                  </View>

                  <View style={style.contentContainer()}>
                    <AppText
                      title={item.name}
                      variant={'h4'}
                      color={COLORS.dark.black}
                      extraStyle={{fontFamily: Fonts.PoppinsMedium}}
                    />
                    <AppText
                      title={`Age${item.age} , ${item.height}`}
                      color={COLORS.dark.inputBorder}
                      extraStyle={{
                        fontFamily: Fonts.PoppinsRegular,
                      }}
                    />
                    <View style={style.locationContainer()}>
                      <CustomImage
                        source={IMAGES.locationIcon}
                        size={10}
                        resizeMode={'contain'}
                      />
                      <Space mL={10} />
                      <AppText
                        title={LABELS.mumbaiIndia}
                        variant={'h5'}
                        extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                      />
                    </View>

                    <View style={style.locationContainer()}>
                      <AppText
                        title={LABELS.castName}
                        variant={'h5'}
                        extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                        color={COLORS.dark.gray}
                      />
                      <Space mL={10} />
                      <AppText
                        title={LABELS.castName}
                        variant={'h5'}
                        extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                        color={COLORS.dark.gray}
                      />
                    </View>
                    <View style={style.btnContainer()}>
                      <TouchableOpacity
                        style={style.sendInterestBtn()}
                        onPress={() => {
                          navigation.navigate('DrawerNavigation');
                        }}>
                        <CustomImage source={IMAGES.sendIcon} size={10} />
                        <Space mL={10} />
                        <AppText
                          title={LABELS.sendInterest}
                          color={COLORS.dark.white}
                          variant={'h5'}
                          extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                        />
                      </TouchableOpacity>
                      <Space mL={5} />
                      <TouchableOpacity style={style.chatBtn()}>
                        <CustomImage source={IMAGES.chatIcon} size={14} />
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              );
            })
          ) : (
            <></>
          )}
        </View>
      </ScrollView>
    </>
  );
};

export default PartnerMatch;
