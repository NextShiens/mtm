import {StyleSheet} from 'react-native';
import {COLORS, HORIZON_MARGIN} from '../../../assets/theme';
export const styles = () =>
  StyleSheet.create({
    headerContainer: () => ({
      height: 70,
      width: '100%',
      borderBottomWidth: 1,
      borderBottomColor: COLORS.dark.lightGrey,
    }),
    searchBoxContainer: () => ({
      width: '100%',
      paddingHorizontal: HORIZON_MARGIN,
      justifyContent: 'space-between',
      flexDirection: 'row',
    }),
    searchBox: () => ({
      height: 50,
      width: '75%',
      backgroundColor: COLORS.dark.lightGrey,
    }),
    filterBtn: () => ({
      height: 50,
      width: '15%',
      backgroundColor: COLORS.dark.secondary,
      borderRadius: 10,
      justifyContent: 'center',
      alignItems: 'center',
    }),
    cardContainer: () => ({
      height: 155,
      // width: 200,
      width: '100%',
      backgroundColor: 'white',
      borderWidth: 1,
      borderColor: COLORS.dark.text,
      flexDirection: 'row',
      borderRadius: 10,
      elevation: 5,
      marginTop: 10,
    }),
    imgContainer: () => ({
      width: '35%',
      borderRadius: 20,
    }),
    contentContainer: () => ({
      justifyContent: 'center',
      paddingHorizontal: HORIZON_MARGIN,
    }),
    gradientOverlay: () => ({
      ...StyleSheet.absoluteFillObject, // Cover the entire container
      borderRadius: 10, // Apply border radius if needed
    }),
    textContainer: () => ({
      width: '100%',
      flexDirection: 'row',
      justifyContent: 'space-between',
      paddingHorizontal: 15,
    }),
    linkContainer: () => ({
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
    }),
    horizontalScrollContainer: () => ({
      width: '100%',
      height: 150,
      // backgroundColor: 'yellow',
    }),
    img: () => ({
      flex: 1,
      borderRadius: 10,
    }),
    sendIconBtn: () => ({
      height: 25,
      width: 25,
      backgroundColor: COLORS.dark.secondary,
      borderRadius: 20,
      justifyContent: 'center',
      alignItems: 'center',
    }),
    chatIconBtn: () => ({
      height: 25,
      width: 25,
      backgroundColor: COLORS.dark.primary,
      borderRadius: 20,
      justifyContent: 'center',
      alignItems: 'center',
    }),
    verifyIconBtn: () => ({
      height: 25,
      width: 25,
      backgroundColor: COLORS.dark.white,
      borderRadius: 20,
      borderWidth: 1,
      borderColor: COLORS.dark.lightGrey,
      justifyContent: 'center',
      alignItems: 'center',
    }),
    image: () => ({
      ...StyleSheet.absoluteFillObject,
      resizeMode: 'cover',
      borderRadius: 10,
    }),
    locationContainer: () => ({
      flexDirection: 'row',
      alignItems: 'center',
    }),
    btnContainer: () => ({
      // width: '95%',
      flexDirection: 'row',
      // alignItems: 'center',
      // justifyContent: 'flex-start',
      // backgroundColor: 'red',
      // alignSelf: 'center',
    }),
    sendInterestBtn: () => ({
      width: '55%',
      height: 40,
      backgroundColor: COLORS.dark.secondary,
      borderRadius: 5,
      justifyContent: 'center',
      flexDirection: 'row',
      alignItems: 'center',
    }),
    chatBtn: () => ({
      width: '20%',
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: COLORS.dark.primary,
      borderRadius: 5,
    }),
  });
