import {StyleSheet} from 'react-native';
import {COLORS, HORIZON_MARGIN} from '../../../assets/theme';
import {Fonts} from '../../../assets/fonts';
export const styles = () =>
  StyleSheet.create({
    container: () => ({
      flex: 1,
    }),
    headerContainer: () => ({
      height: 70,
      width: '100%',
      borderBottomWidth: 1,
      borderBottomColor: COLORS.dark.lightGrey,
    }),
    contentContainer: () => ({
      paddingHorizontal: HORIZON_MARGIN,
    }),
    searchBoxContainer: () => ({
      width: '100%',
      paddingHorizontal: HORIZON_MARGIN,
      justifyContent: 'space-between',
      flexDirection: 'row',
    }),
    searchBox: () => ({
      height: 50,
      width: '75%',
      backgroundColor: COLORS.dark.lightGrey,
    }),
    filterBtn: () => ({
      height: 50,
      width: '15%',
      backgroundColor: COLORS.dark.secondary,
      borderRadius: 10,
      justifyContent: 'center',
      alignItems: 'center',
    }),
    interestSendBtn: () => ({
      width: '100%',
      backgroundColor: COLORS.dark.secondary,
      borderRadius: 10,
    }),
    btnLabel: () => ({
      fontFamily: Fonts.PoppinsRegular,
      fontSize: 14,
    }),
    btnContainer: () => ({
      flexDirection: 'row',
      width: '100%',
      justifyContent: 'space-evenly',
      paddingHorizontal: 15,
      alignSelf: 'center',
    }),
  });
