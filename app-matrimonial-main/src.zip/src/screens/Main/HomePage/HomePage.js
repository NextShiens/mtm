import React from 'react';
import {View, Text, TouchableOpacity, ScrollView} from 'react-native';
import AppHeader from '../../../components/AppHeader/AppHeader';
import {LABELS} from '../../../labels';
import {SVG} from '../../../assets/svg';
import CustomImage from '../../../components/CustomImage/CustomImage';
import {IMAGES} from '../../../assets/images';
import {styles} from './styles';
import AppInput from '../../../components/AppInput/AppInput';
import Space from '../../../components/Space/Space';
import {COLORS, HORIZON_MARGIN, STYLES} from '../../../assets/theme';
import HorizontalScreen from '../../../components/HorizontalScroll/HorizontalScreen';
import {
  HorizontalCardData,
  carouselData,
  filterOptions,
} from '../../../data/appData';
import {useNavigation} from '@react-navigation/native';
import HorizontalCard from '../../../components/HorizontalCard/HorizontalCard';
import CarouselCard from '../../../components/Carousel/CarouselCard';
import IconButton from '../../../components/IconButton/IconButton';
import AppText from '../../../components/AppText/AppText';
import {Fonts} from '../../../assets/fonts';

const HomePage = ({navigation}) => {
  const style = styles();
  //handle left icon press
  const handleLeftIconPress = () => {
    navigation.openDrawer();
    console.log('left icon pressed');
  };

  //handle right icon press
  const handleRightIconPress = () => {
    navigation.navigate('NotificationScreen');
    console.log('right icon pressed');
  };
  //handle item press
  const handleItemPress = item => {
    console.log('Selected Item:', item);
  };
  //handle search functionality
  const handlesearchFunctionality = item => {
    console.log('search functionality', item);
  };
  const handlesearchBtn = () => {
    console.log('search button pressed');
  };
  const showMoreUserHandler = () => {
    console.log('link pressed');
  };
  const sendInterestHandler = () => {
    console.log('send interest pressed');
  };
  const chatPressHandler = () => {
    console.log('chat pressed');
  };
  return (
    <ScrollView style={{flex: 1}}>
      <View style={style.container()}>
        <View style={style.headerContainer()}>
          <AppHeader
            iconLeft={
              <>
                <TouchableOpacity onPress={handleLeftIconPress}>
                  <CustomImage
                    source={IMAGES.menuIcon}
                    size={17}
                    resizeMode={'contain'}
                  />
                </TouchableOpacity>
              </>
            }
            iconRight={
              <TouchableOpacity onPress={handleRightIconPress}>
                <CustomImage
                  source={IMAGES.notificationIcon}
                  size={27}
                  resizeMode={'contain'}
                />
              </TouchableOpacity>
            }
          />
        </View>

        <Space mT={20} />
        <View style={style.contentContainer}>
          <View style={style.searchBoxContainer()}>
            <AppInput
              iconLeft={<SVG.magnifyingGlass fill={'black'} />}
              extraStyle={{
                textInputCont: {
                  width: '80%',
                  backgroundColor: COLORS.dark.searchBox,
                  borderWidth: 0,
                },
              }}
              placeholder={LABELS.searchHere}
              onChangeText={handlesearchFunctionality}
            />
            <TouchableOpacity
              style={style.filterBtn()}
              activeOpacity={0.8}
              onPress={handlesearchBtn}>
              <CustomImage
                source={IMAGES.filterIcon}
                size={17}
                resizeMode={'contain'}
              />
            </TouchableOpacity>
          </View>
          <Space mT={20} />
          <HorizontalScreen data={filterOptions} onPress={handleItemPress} />
          <Space mT={20} />
          <View style={{paddingHorizontal: 15, borderRadius: 10}}>
            <CarouselCard />
          </View>
          <Space mT={20} />
          <View style={style.btnContainer()}>
            <TouchableOpacity
              onPress={sendInterestHandler}
              style={{width: '40%'}}>
              <IconButton
                variant={'filled'}
                iconLeft={
                  <SVG.vectorIcon fill={'white'} alignSelf={'center'} />
                }
                title={LABELS.sendInterest}
                onPressText={sendInterestHandler}
                textAlign="center"
                extraStyle={{
                  container: style.interestSendBtn(),
                  text: style.btnLabel(),
                }}
                onLeftIconPress={sendInterestHandler}
                onPress={sendInterestHandler}
              />
            </TouchableOpacity>

            <TouchableOpacity
              style={{
                width: '40%',
                backgroundColor: COLORS.dark.primary,
                borderRadius: 10,
                justifyContent: 'center',
                flexDirection: 'row',
                alignItems: 'center',
              }}
              onPress={chatPressHandler}
              activeOpacity={0.4}>
              <CustomImage
                source={IMAGES.chatIcon}
                size={12}
                resizeMode={'contain'}
              />
              <Space mL={10} />
              <AppText
                title={LABELS.chat}
                color={COLORS.dark.white}
                variant={'h5'}
                extraStyle={{fontFamily: Fonts.PoppinsRegular}}
                onPress={chatPressHandler}
              />
            </TouchableOpacity>
          </View>
          <Space mT={20} />
          <View style={[STYLES.pL(HORIZON_MARGIN)]}>
            <HorizontalCard
              data={HorizontalCardData}
              onLinkPress={showMoreUserHandler}
            />
          </View>
        </View>
      </View>
    </ScrollView>
  );
};

export default HomePage;
