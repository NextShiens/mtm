import { View, Text } from 'react-native'
import React from 'react'

const SettingScreen = () => {
  return (
    <View>
      <Text>SettingScreen</Text>
    </View>
  )
}

export default SettingScreen