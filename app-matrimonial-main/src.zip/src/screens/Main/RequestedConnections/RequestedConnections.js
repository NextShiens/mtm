import { View, Text } from 'react-native'
import React from 'react'
import { styles } from './styles'
const RequestedConnections = () => {
    const style = styles()
  return (
    <View>
      <Text>RequestedConnections</Text>
    </View>
  )
}

export default RequestedConnections