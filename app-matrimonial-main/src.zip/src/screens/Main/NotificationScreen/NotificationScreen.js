import {View, Text, ScrollView, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {SVG} from '../../../assets/svg';
import {LABELS} from '../../../labels';
import {IMAGES} from '../../../assets/images';
import CustomImage from '../../../components/CustomImage/CustomImage';
import AppHeader from '../../../components/AppHeader/AppHeader';
import NotificationCard from '../../../components/NotificationCard/NotificationCard';
import {notificationsData} from '../../../data/appData';
import Space from '../../../components/Space/Space';

const NotificationScreen = ({navigation}) => {
  const style = styles();
  const handleRightIconPress = () => {
    console.log('notification bell pressed');
    console.log(formattedDate);
  };
  const handleNotificationPress = () => {
    console.log('notification pressed');
  };
  return (
    <ScrollView>
      <View style={style.headerContainer()}>
        <AppHeader
          iconLeft={<SVG.BackArrow fill={'black'} />}
          onLeftIconPress={() => {
            navigation.goBack();
          }}
          title={LABELS.notification}
          iconRight={
            <TouchableOpacity onPress={handleRightIconPress}>
              <CustomImage
                source={IMAGES.notificationIcon}
                size={27}
                resizeMode={'contain'}
              />
            </TouchableOpacity>
          }
        />
      </View>
      <Space mT={20} />
      <NotificationCard
        data={notificationsData}
        onPress={handleNotificationPress}
      />
    </ScrollView>
  );
};

export default NotificationScreen;
