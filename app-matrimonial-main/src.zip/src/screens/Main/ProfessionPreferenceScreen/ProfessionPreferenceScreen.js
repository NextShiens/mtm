import {View, Text, ScrollView, TouchableOpacity} from 'react-native';
import React, {useState} from 'react';
import {styles} from './styles';
import {IMAGES} from '../../../assets/images';
import {SVG} from '../../../assets/svg';
import {LABELS} from '../../../labels';
import AppHeader from '../../../components/AppHeader/AppHeader';
import CustomImage from '../../../components/CustomImage/CustomImage';
import AppInput from '../../../components/AppInput/AppInput';
import {COLORS, HORIZON_MARGIN, STYLES} from '../../../assets/theme';
import Space from '../../../components/Space/Space';
import {professionPreferenceData} from '../../../data/appData';
import HorizontalScrollCategories from '../../../components/HorizontalScrollCategories/HorizontalScrollCategories.js';

const ProfessionPreferenceScreen = () => {
  //handle right icon press
  const handleRightIconPress = () => {
    console.log('right icon pressed');
  };
  //handle item press
  const handleLeftIconPress = () => {
    console.log('left icon pressed');
  };
  const handlesearchFunctionality = () => {
    console.log('search functionality');
  };

  const handleItemPress = item => {
    console.log('Selected Item:', item);
    const selectedProfession = item.name;
    // Accessing selected subcategory (if any)
    if (item.value) {
      const selectedSubcategory = item.value;
      console.log('Selected Subcategory:', selectedSubcategory);
      // Handle selected subcategory logic here
    } else {
      // Handle selected profession logic here
      console.log('Selected Profession:', selectedProfession);
    }
  };
  const [professions, setProfessions] = useState([]);

  const style = styles();
  return (
    <ScrollView style={{flex: 1}}>
      <View>
        <View style={style.headerContainer()}>
          <AppHeader
            iconLeft={<SVG.BackArrow fill={'black'} />}
            title={LABELS.preference}
            iconRight={
              <TouchableOpacity onPress={handleRightIconPress}>
                <CustomImage
                  source={IMAGES.notificationIcon}
                  size={27}
                  resizeMode={'contain'}
                />
              </TouchableOpacity>
            }
          />
        </View>
        <Space mT={20} />
        <View style={style.searchBoxContainer()}>
          <AppInput
            iconLeft={<SVG.magnifyingGlass fill={'black'} />}
            extraStyle={{
              textInputCont: {
                width: '100%',
                borderColor: COLORS.dark.inputBorder,
                backgroundColor: '#FBFCFF',
                borderWidth: 1,
                borderRadius: 10,
              },
            }}
            placeholder={LABELS.searchHere}
            onChangeText={handlesearchFunctionality}
          />
        </View>
        <Space mT={20} />
        <View style={[STYLES.width('100%'), STYLES.pH(HORIZON_MARGIN)]}>
          <HorizontalScrollCategories
            data={professionPreferenceData}
            onPress={item => {
              console.log('item', item);
            }}
          />
        </View>
        <Space mT={20} />
      </View>
    </ScrollView>
  );
};

export default ProfessionPreferenceScreen;
