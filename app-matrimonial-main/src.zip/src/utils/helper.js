export function searchItems(items, query) {
  const lowercasedQuery = query.toLowerCase();
  const filteredItems = items.filter(item =>
    item.toLowerCase().includes(lowercasedQuery),
  );
  const errorMessage =
    filteredItems.length === 0 ? 'No items found matching your search.' : '';

  return {
    filteredItems,
    errorMessage,
  };
}
export function getTimeDifference(notificationTimestamp) {
  const notificationDate = new Date(notificationTimestamp);
  const currentDate = new Date();
  const timeDifference = currentDate - notificationDate;

  const minutes = Math.floor(timeDifference / (1000 * 60));
  const hours = Math.floor(timeDifference / (1000 * 60 * 60));
  const days = Math.floor(timeDifference / (1000 * 60 * 60 * 24));

  if (days > 0) {
    if (days === 1) {
      return 'Yesterday';
    } else {
      const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const dayIndex = notificationDate.getDay();
      return dayNames[dayIndex];
    }
  } else if (hours > 0) {
    return `${hours}h ago`;
  } else if (minutes > 0) {
    return `${minutes} min ago`;
  } else {
    return 'Just now';
  }
}
