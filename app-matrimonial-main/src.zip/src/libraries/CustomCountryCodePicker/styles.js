import {StyleSheet} from 'react-native';
import {COLORS, HORIZON_MARGIN} from '../../assets/theme';
export const styles = () =>
  StyleSheet.create({
    countryContainer: () => ({
      height: 50,
      width: '10%',
      borderRadius: 6,
      justifyContent: 'center',
    }),
    text: () => ({
      color: COLORS.dark.black,
      fontSize: 17,
    }),
  });
