import React, {useRef, useEffect, useState} from 'react';
import {View, TextInput, StyleSheet} from 'react-native';
import {COLORS} from '../../assets/theme';

const OTPTextInput = ({length, onChangeText, value}) => {
  const inputs = Array(length).fill(0);
  const inputRefs = Array(length)
    .fill(0)
    .map((_, i) => useRef(null));
  const [focusedIndex, setFocusedIndex] = useState(0);

  const focusInput = index => {
    if (inputRefs[index] && inputRefs[index].current) {
      inputRefs[index].current.focus();
    }
  };

  const handleInputChange = (index, text) => {
    if (text) {
      onChangeText(index, text);
      if (index < length - 1) {
        focusInput(index + 1);
      }
    } else {
      onChangeText(index, text);
      if (index > 0) {
        focusInput(index - 1);
      }
    }
  };

  useEffect(() => {
    focusInput(0); // Focus on the first input field initially
  }, []);

  return (
    <View style={styles.container}>
      {inputs.map((_, index) => (
        <TextInput
          key={index}
          style={[styles.input, focusedIndex === index && styles.focusedInput]}
          maxLength={1}
          keyboardType="numeric"
          onChangeText={text => handleInputChange(index, text)}
          value={value[index]}
          ref={inputRefs[index]}
          onFocus={() => setFocusedIndex(index)}
        />
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  input: {
    width: 65,
    height: 55,
    borderWidth: 1,
    borderColor: 'transparent',
    backgroundColor: COLORS.light.OTPInput,
    borderRadius: 10,
    textAlign: 'center',
    fontSize: 18,
    marginHorizontal: 5,
    color: COLORS.dark.black,
  },
  focusedInput: {
    borderColor: COLORS.dark.primary, // Change the border color when focused
  },
});

export default OTPTextInput;
