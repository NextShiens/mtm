import React, {useState} from 'react';
import {View, TextInput, StyleSheet, Text, Button} from 'react-native';
import CountryPicker from 'react-native-country-picker-modal';
import {styles} from './styles';
import AppInput from '../../components/AppInput/AppInput';
import {COLORS} from '../../assets/theme';
import {LABELS} from '../../labels';

const CustomCountryPicker = ({
  onContactEnter,
  countryCallingCode2,
  placeholder,
  onCountrySelect,
  value,
}) => {
  const [countryCode, setCountryCode] = useState('+91');
  const [completeNum, setCompleteNum] = useState('');

  const style = styles();
  return (
    <CountryPicker
      onSelect={onCountrySelect}
      withFilter={true}
      placeholder={placeholder ? `+${placeholder}` : countryCode}
    />
  );
};

export default CustomCountryPicker;
