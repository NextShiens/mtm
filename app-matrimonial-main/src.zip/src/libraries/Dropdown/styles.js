import {StyleSheet} from 'react-native';
import {COLORS} from '../../assets/theme';
import { Fonts } from '../../assets/fonts';
export const styles = () =>
  StyleSheet.create({
    boxStyles: () => ({
      height: 50,
      width: '100%',
      borderColor: COLORS.dark.inputBorder,
      borderRadius: 6,
    }),
    inputStyles: () => ({
      fontFamily: Fonts.PoppinsRegular,
      color: COLORS.dark.inputBorder,
    }),
    dropdownStyles: () => ({
      borderColor: COLORS.dark.inputBorder,
    }),
    dropdownTextStyles: () => ({
      fontFamily: Fonts.PoppinsRegular,
      color: COLORS.dark.inputBorder,
    }),
  });
