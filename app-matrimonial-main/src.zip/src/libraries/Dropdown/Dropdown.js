import React, {useState} from 'react';
import {Text, View} from 'react-native';
import {SelectList} from 'react-native-dropdown-select-list';
import {styles} from './styles';
import CustomImage from '../../components/CustomImage/CustomImage';
import {IMAGES} from '../../assets/images';
import {genderList} from '../../data/appData';
const CustomDropdown = ({
  placeholder,
  data,
  search = false,
  defaultOption,
  setSelected,
  arrowIcon,
  searchPlaceholder,
  onSelect = () => {},
  dropdownShown,
}) => {
  const style = styles();
  return (
    <View>
      <SelectList
        setSelected={setSelected}
        data={data ? data : genderList}
        save="value"
        placeholder={placeholder ? placeholder : 'Select any option'}
        search={search}
        defaultOption={defaultOption}
        arrowicon={
          arrowIcon ? (
            arrowIcon
          ) : (
            <CustomImage
              source={IMAGES.vectorIcon}
              size={10}
              resizeMode={'contain'}
            />
          )
        }
        searchPlaceholder={searchPlaceholder}
        onSelect={onSelect}
        dropdownShown={dropdownShown}
        boxStyles={style.boxStyles()}
        inputStyles={style.inputStyles()}
        dropdownStyles={style.dropdownStyles()}
        dropdownTextStyles={style.dropdownTextStyles()}
      />
    </View>
  );
};

export default CustomDropdown;
