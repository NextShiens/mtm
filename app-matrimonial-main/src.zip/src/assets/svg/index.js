export const SVG = {
  BackArrow: require('./backArrow.svg').default,
  CheckboxFilled: require('./checkboxFilled.svg').default,
  checkboxUnfilled: require('./checkboxUnfilled.svg').default,
  magnifyingGlass: require('./MagnifyingGlass.svg').default,
  vectorIcon: require('./vectorIcon.svg').default,
  locationIconSVG: require('./locationIcon.svg').default,
  squareBox:require('./SquareIcon.svg').default,
  userIcon:require('./UserIcon.svg').default,
  heartIcon:require('./HeartIcon.svg').default,
  envelopeIcon:require('./EnvelopIcon.svg').default,
  bell:require('./Bellicon.svg').default,
  homeIcon:require('./HomeIcon.svg').default,


  
};
